import json
from asyncio import Lock
from copy import deepcopy

import nats
from aiocache import cached
from nats.js.client import JetStreamContext
from nats.js.kv import KeyValue
from sqlalchemy.ext.asyncio import AsyncSession

from app import on_shutdown, on_startup
from app.core.manager import core_manager
from app.db import GetDB
from app.db.crud.host import get_host_by_id, get_hosts, upsert_inbounds
from app.db.models import ProxyHostSecurity
from app.models.host import BaseHost, FinalMask, TransportSettings, WireGuardHostOverrides
from app.models.subscription import (
    GRPCTransportConfig,
    KCPTransportConfig,
    QUICTransportConfig,
    SubscriptionInboundData,
    TCPTransportConfig,
    TLSConfig,
    WebSocketTransportConfig,
    XHTTPTransportConfig,
)
from app.nats import is_multi_worker, is_nats_enabled
from app.nats.client import setup_nats_kv
from app.nats.kv_cas import is_kv_miss
from app.nats.message import MessageTopic
from app.nats.router import router
from app.utils.logger import get_logger
from config import runtime_settings
from role import Role
from app.subscription.base import normalize_and_remove_none_values


def _string_list(value) -> list[str]:
    if value is None:
        return []
    if isinstance(value, str):
        return [value]
    if isinstance(value, dict):
        value = value.keys()
    try:
        return [str(item) for item in value]
    except TypeError:
        return [str(value)]


def _normalize_finalmask_link(final_mask_settings: FinalMask | dict | str | None) -> str | None:
    if not final_mask_settings:
        return None
    fms = None
    if isinstance(final_mask_settings, FinalMask):
        fms = final_mask_settings.model_dump(by_alias=True, exclude_none=True)
    elif isinstance(final_mask_settings, dict):
        fms = deepcopy(final_mask_settings)
    elif isinstance(final_mask_settings, str):
        try:
            fms = json.loads(final_mask_settings)
        except Exception:
            return final_mask_settings

    if isinstance(fms, dict):
        fms = normalize_and_remove_none_values(fms)

    if fms:
        return json.dumps(fms, separators=(",", ":"))
    return None


async def _prepare_subscription_inbound_data(
    host: BaseHost,
    down_settings: SubscriptionInboundData | None = None,
) -> SubscriptionInboundData:
    """
    Prepare host data - creates small config instances ONCE.
    Merges inbound config with host config.
    Random selection happens in share.py on every request!
    """
    # Get inbound configuration
    inbound_config = await core_manager.get_inbound_by_tag(host.inbound_tag)
    protocol = inbound_config["protocol"]

    ts = host.transport_settings
    if isinstance(ts, dict):
        ts = TransportSettings.model_validate(ts) if ts else None

    network = inbound_config.get("network", "tcp")
    path = host.path or inbound_config.get("path", "")

    final_mask_settings = host.final_mask_settings if host.final_mask_settings else inbound_config.get("finalmask")
    finalmask_link = _normalize_finalmask_link(final_mask_settings)

    if protocol == "wireguard":
        wg_over: WireGuardHostOverrides | None = host.wireguard_overrides
        if wg_over is None:
            wg_over = WireGuardHostOverrides()

        default_allowed = ["0.0.0.0/0", "::/0"]
        allowed_ips = (
            list(wg_over.allowed_ips)
            if wg_over.allowed_ips is not None and len(wg_over.allowed_ips) > 0
            else list(default_allowed)
        )

        keepalive = None
        if wg_over.keepalive_seconds is not None:
            keepalive = wg_over.keepalive_seconds if wg_over.keepalive_seconds > 0 else None

        reserved = wg_over.reserved.strip() if wg_over.reserved else None

        dns = list(wg_over.dns) if wg_over.dns else None

        return SubscriptionInboundData(
            remark=host.remark,
            inbound_tag=host.inbound_tag,
            protocol=protocol,
            address=list(host.address) if host.address else ["{SERVER_IP}"],
            port=[host.port] if host.port else [inbound_config.get("listen_port")],
            network=network,
            tls_config=TLSConfig(),
            transport_config=TCPTransportConfig(path="", host=[]),
            mux_settings=None,
            wireguard_public_key=inbound_config.get("public_key", ""),
            wireguard_pre_shared_key=inbound_config.get("pre_shared_key", None),
            wireguard_local_address=inbound_config.get("address", []) or [],
            wireguard_allowed_ips=allowed_ips,
            wireguard_keepalive=keepalive,
            wireguard_mtu=wg_over.mtu,
            wireguard_reserved=reserved,
            wireguard_dns=dns,
            fragment_settings=host.fragment_settings.model_dump() if host.fragment_settings else None,
            noise_settings=host.noise_settings.model_dump() if host.noise_settings else None,
            finalmask=final_mask_settings,
            finalmask_link=finalmask_link,
            priority=host.priority,
            status=list(host.status) if host.status else None,
            subscription_templates=host.subscription_templates.model_dump(exclude_none=True)
            if host.subscription_templates
            else None,
        )

    sni_list = _string_list(host.sni) if host.sni else _string_list(inbound_config.get("sni", []))
    host_list = _string_list(host.host) if host.host else _string_list(inbound_config.get("host", []))
    address_list = _string_list(host.address) if host.address else []

    # Get Reality fields from inbound if applicable
    reality_pbk = inbound_config.get("pbk", "")
    reality_sid = inbound_config.get("sid", "")
    reality_sids = inbound_config.get("sids", [])
    mldsa65_verify = inbound_config.get("mldsa65Verify")
    reality_spx = inbound_config.get("spx") or ""  # Convert None to empty string

    # Merge TLS settings: host overrides inbound defaults
    tls_value = None if host.security == ProxyHostSecurity.inbound_default else host.security.value
    if tls_value is None:
        tls_value = inbound_config.get("tls", "none")

    pinned_peer_cert_sha256 = (
        host.pinned_peer_cert_sha256 if host.pinned_peer_cert_sha256 else inbound_config.get("pinnedPeerCertSha256", "")
    )
    verify_peer_cert_by_name = _string_list(host.verify_peer_cert_by_name) if host.verify_peer_cert_by_name else []
    ech = host.ech
    xray_ech = ech.xray if ech else None
    mihomo_ech = ech.mihomo if ech else None
    sing_box_ech = ech.sing_box if ech else None
    ech_query_strategy = (xray_ech.query_strategy if xray_ech else None) or inbound_config.get("echForceQuery")
    alpn_list = [alpn.value for alpn in host.alpn] if host.alpn else inbound_config.get("alpn", [])
    fp = host.fingerprint.value if host.fingerprint.value != "none" else inbound_config.get("fp")
    fp = fp or ("chrome" if tls_value == "reality" else "")

    ais = host.allowinsecure if host.allowinsecure is not None else inbound_config.get("allowinsecure", False)

    # Create TLS config once with merged data
    tls_config = TLSConfig(
        tls=tls_value if tls_value != "none" else None,
        sni=sni_list,
        fingerprint=fp,
        allowinsecure=ais,
        pinned_peer_cert_sha256=pinned_peer_cert_sha256,
        verify_peer_cert_by_name=verify_peer_cert_by_name,
        alpn_list=alpn_list,
        ech_config_list=xray_ech.config_list if xray_ech else None,
        ech_query_strategy=ech_query_strategy,
        mihomo_ech_config=mihomo_ech.config if mihomo_ech else None,
        mihomo_ech_query_server_name=mihomo_ech.query_server_name if mihomo_ech else None,
        sing_box_ech_config=sing_box_ech.config if sing_box_ech else None,
        sing_box_ech_query_server_name=sing_box_ech.query_server_name if sing_box_ech else None,
        reality_public_key=reality_pbk,
        reality_short_id=reality_sid,
        reality_short_ids=reality_sids,
        reality_spx=reality_spx,
        mldsa65_verify=mldsa65_verify,
        cipher_suites=host.cipher_suites,
    )

    # Merge port: host overrides inbound (store as list for random selection)
    if host.port:
        # Host port is always an int
        port_list = [host.port]
    else:
        # Inbound port can be int or comma-separated string like "8080,8443,9090"
        inbound_port = inbound_config.get("port")
        if inbound_port:
            if isinstance(inbound_port, int):
                port_list = [inbound_port]
            elif isinstance(inbound_port, str):
                # Parse comma-separated string
                port_list = [int(p.strip()) for p in inbound_port.split(",") if p.strip()]
            else:
                port_list = []
        else:
            port_list = []

    # Get shadowsocks specific fields from inbound
    is_2022 = inbound_config.get("is_2022", False)
    ss_method = inbound_config.get("method", "")
    ss_password = inbound_config.get("password", "")

    # Get VLESS encryption from inbound
    encryption = inbound_config.get("encryption", "none")

    # Get flow from inbound for subscription generation.
    inbound_flow = inbound_config.get("flow", "")
    if inbound_flow == "none":
        inbound_flow = ""

    # Network comes from inbound, NOT from checking which transport exists on host!
    # Host can have ALL transport configs, inbound determines which one is used

    # Get header_type from inbound (will be used for QUIC, TCP)
    inbound_header_type = inbound_config.get("header_type", "none")

    # Create transport config based on network type from inbound
    # Always create the config, merge host settings with inbound defaults (host overrides inbound)
    if network in ("xhttp", "splithttp"):
        xs = ts.xhttp_settings if ts else None
        mode = inbound_config.get("mode", "")
        if xs:
            if xs.mode is None:
                mode = inbound_config.get("mode", "")
            else:
                mode = xs.mode.value
        transport_config = XHTTPTransportConfig(
            path=path,
            host=host_list,
            mode=mode,
            no_grpc_header=xs.no_grpc_header
            if xs and xs.no_grpc_header is not None
            else inbound_config.get("no_grpc_header"),
            sc_max_each_post_bytes=(
                xs.sc_max_each_post_bytes
                if xs and xs.sc_max_each_post_bytes is not None
                else inbound_config.get("sc_max_each_post_bytes")
            ),
            sc_min_posts_interval_ms=(
                xs.sc_min_posts_interval_ms
                if xs and xs.sc_min_posts_interval_ms is not None
                else inbound_config.get("sc_min_posts_interval_ms")
            ),
            x_padding_bytes=xs.x_padding_bytes
            if xs and xs.x_padding_bytes is not None
            else inbound_config.get("x_padding_bytes"),
            x_padding_obfs_mode=(
                xs.x_padding_obfs_mode
                if xs and xs.x_padding_obfs_mode is not None
                else inbound_config.get("x_padding_obfs_mode")
            ),
            x_padding_key=xs.x_padding_key
            if xs and xs.x_padding_key is not None
            else inbound_config.get("x_padding_key"),
            x_padding_header=(
                xs.x_padding_header
                if xs and xs.x_padding_header is not None
                else inbound_config.get("x_padding_header")
            ),
            x_padding_placement=(
                xs.x_padding_placement
                if xs and xs.x_padding_placement is not None
                else inbound_config.get("x_padding_placement")
            ),
            x_padding_method=(
                xs.x_padding_method
                if xs and xs.x_padding_method is not None
                else inbound_config.get("x_padding_method")
            ),
            uplink_http_method=(
                xs.uplink_http_method
                if xs and xs.uplink_http_method is not None
                else inbound_config.get("uplink_http_method")
            ),
            session_placement=(
                xs.session_placement
                if xs and xs.session_placement is not None
                else inbound_config.get("session_placement")
            ),
            session_key=xs.session_key if xs and xs.session_key is not None else inbound_config.get("session_key"),
            session_id_table=(
                xs.session_id_table
                if xs and xs.session_id_table is not None
                else inbound_config.get("session_id_table")
            ),
            session_id_length=(
                xs.session_id_length
                if xs and xs.session_id_length is not None
                else inbound_config.get("session_id_length")
            ),
            seq_placement=(
                xs.seq_placement if xs and xs.seq_placement is not None else inbound_config.get("seq_placement")
            ),
            seq_key=xs.seq_key if xs and xs.seq_key is not None else inbound_config.get("seq_key"),
            uplink_data_placement=(
                xs.uplink_data_placement
                if xs and xs.uplink_data_placement is not None
                else inbound_config.get("uplink_data_placement")
            ),
            uplink_data_key=(
                xs.uplink_data_key if xs and xs.uplink_data_key is not None else inbound_config.get("uplink_data_key")
            ),
            uplink_chunk_size=(
                xs.uplink_chunk_size
                if xs and xs.uplink_chunk_size is not None
                else inbound_config.get("uplink_chunk_size")
            ),
            xmux=xs.xmux.model_dump(by_alias=True, exclude_none=True) if xs and xs.xmux else inbound_config.get("xmux"),
            download_settings=down_settings if xs and down_settings else inbound_config.get("download_settings"),
            http_headers=host.http_headers if host.http_headers is not None else inbound_config.get("http_headers"),
            random_user_agent=host.random_user_agent,
        )
    elif network in ("grpc", "gun"):
        gs = ts.grpc_settings if ts else None
        transport_config = GRPCTransportConfig(
            path=path,
            host=host_list,
            multi_mode=gs.multi_mode if gs else False,
            idle_timeout=gs.idle_timeout if gs else None,
            health_check_timeout=gs.health_check_timeout if gs else None,
            permit_without_stream=gs.permit_without_stream if gs else False,
            initial_windows_size=gs.initial_windows_size if gs else None,
            http_headers=host.http_headers,
            random_user_agent=host.random_user_agent,
        )
    elif network == "kcp":
        ks = ts.kcp_settings if ts else None
        inbound_mtu = inbound_config.get("mtu")
        inbound_tti = inbound_config.get("tti")
        inbound_uplink_capacity = inbound_config.get("uplink_capacity")
        inbound_downlink_capacity = inbound_config.get("downlink_capacity")
        inbound_congestion = inbound_config.get("congestion")
        inbound_read_buffer_size = inbound_config.get("read_buffer_size")
        inbound_write_buffer_size = inbound_config.get("write_buffer_size")
        transport_config = KCPTransportConfig(
            path="",
            host=[],
            mtu=ks.mtu if ks and ks.mtu is not None else inbound_mtu,
            tti=ks.tti if ks and ks.tti is not None else inbound_tti,
            uplink_capacity=ks.uplink_capacity if ks and ks.uplink_capacity is not None else inbound_uplink_capacity,
            downlink_capacity=ks.downlink_capacity
            if ks and ks.downlink_capacity is not None
            else inbound_downlink_capacity,
            congestion=ks.congestion
            if ks and ks.congestion is not None
            else (inbound_congestion if inbound_congestion is not None else False),
            read_buffer_size=ks.read_buffer_size
            if ks and ks.read_buffer_size is not None
            else inbound_read_buffer_size,
            write_buffer_size=ks.write_buffer_size
            if ks and ks.write_buffer_size is not None
            else inbound_write_buffer_size,
        )
    elif network == "quic":
        qs = ts.quic_settings if ts else None
        transport_config = QUICTransportConfig(
            path=path,
            host=host_list,
            header_type=qs.header if qs else inbound_header_type,
        )
    elif network in ("ws", "websocket", "httpupgrade"):
        ws = ts.websocket_settings if ts else None
        transport_config = WebSocketTransportConfig(
            path=path,
            host=host_list,
            heartbeat_period=ws.heartbeatPeriod if ws else None,
            http_headers=host.http_headers,
            random_user_agent=host.random_user_agent,
        )
    elif network in ("tcp", "raw", "http", "h2"):
        # TCP/HTTP/H2 all use TCP transport
        tcps = ts.tcp_settings if ts else None
        header_type = inbound_header_type
        if tcps:
            if tcps.header == "":
                header_type = inbound_header_type
            else:
                header_type = tcps.header

        transport_config = TCPTransportConfig(
            path=path,
            host=host_list,
            header_type=header_type,
            request=tcps.request.model_dump(by_alias=True, exclude_none=True) if tcps and tcps.request else None,
            response=tcps.response.model_dump(by_alias=True, exclude_none=True) if tcps and tcps.response else None,
            http_headers=host.http_headers,
            random_user_agent=host.random_user_agent,
        )
    else:
        # Unknown network type, default to TCP
        transport_config = TCPTransportConfig(
            path=path,
            host=host_list,
            header_type=inbound_header_type,
            http_headers=host.http_headers,
            random_user_agent=host.random_user_agent,
        )

    return SubscriptionInboundData(
        remark=host.remark,
        inbound_tag=host.inbound_tag,
        protocol=protocol,
        address=address_list,
        port=port_list,  # Store the LIST for random selection!
        network=network,
        tls_config=tls_config,
        transport_config=transport_config,
        mux_settings=host.mux_settings.model_dump(by_alias=True, exclude_none=True) if host.mux_settings else None,
        is_2022=is_2022,
        method=ss_method,
        password=ss_password,
        encryption=encryption,
        vless_route=host.vless_route,
        inbound_flow=inbound_flow,
        random_user_agent=host.random_user_agent,
        use_sni_as_host=host.use_sni_as_host,
        fragment_settings=host.fragment_settings.model_dump() if host.fragment_settings else None,
        noise_settings=host.noise_settings.model_dump() if host.noise_settings else None,
        finalmask=final_mask_settings,
        finalmask_link=finalmask_link,
        priority=host.priority,
        status=list(host.status) if host.status else None,
        subscription_templates=host.subscription_templates.model_dump(exclude_none=True)
        if host.subscription_templates
        else None,
    )


class HostManager:
    STATE_CACHE_KEY = "state"
    KV_BUCKET_NAME = "host_manager_state"

    def __init__(self):
        self._hosts = {}
        self._lock = Lock()
        self._nats_enabled = is_nats_enabled()
        self._multi_worker = is_multi_worker()
        self._nc: nats.NATS | None = None
        self._js: JetStreamContext | None = None
        self._kv: KeyValue | None = None
        self._logger = get_logger("host-manager")
        self._add_hosts_impl = (
            self._add_hosts_nats if (self._nats_enabled and self._multi_worker) else self._add_hosts_local
        )
        self._remove_host_impl = (
            self._remove_host_nats if (self._nats_enabled and self._multi_worker) else self._remove_host_local
        )

    async def _snapshot_state(self) -> dict[int, dict]:
        async with self._lock:
            return dict(self._hosts)

    async def _persist_state(self):
        if not self._kv:
            return
        state = await self._snapshot_state()
        # Serialize state to JSON using Pydantic model_dump
        serializable_state = {
            str(host_id): (host_data.model_dump() if isinstance(host_data, SubscriptionInboundData) else host_data)
            for host_id, host_data in state.items()
        }
        state_bytes = json.dumps(serializable_state).encode("utf-8")
        try:
            await self._kv.put(self.STATE_CACHE_KEY, state_bytes)
        except Exception as exc:
            self._logger.warning(f"Failed to persist host state to NATS KV: {exc}")

    async def _load_state_from_cache(self) -> bool:
        if not self._kv:
            return False

        try:
            entry = await self._kv.get(self.STATE_CACHE_KEY)
            if not entry or not entry.value:
                return False

            value = entry.value
            # Deserialize state using JSON
            try:
                cached_state = json.loads(value.decode("utf-8"))
            except json.JSONDecodeError, UnicodeDecodeError:
                self._logger.warning("Failed to decode HostManager state as JSON, ignoring...")
                return False

            # Convert dict values back to SubscriptionInboundData models
            converted_state = {}
            for host_id_str, host_data in cached_state.items():
                try:
                    host_id = int(host_id_str)
                    if isinstance(host_data, dict):
                        converted_state[host_id] = SubscriptionInboundData.model_validate(host_data)
                    else:
                        converted_state[host_id] = host_data
                except ValueError, TypeError:
                    self._logger.warning(f"Failed to convert host data for host ID {host_id_str}: {host_data}")
                    continue

            async with self._lock:
                self._hosts = converted_state
            await self._reset_cache()
            return True
        except Exception as exc:
            if is_kv_miss(exc):
                self._logger.debug("Host manager state cache is empty")
                return False
            self._logger.error(f"Error loading host state from cache: {exc}")
            return False

    async def _reload_from_cache(self):
        loaded = await self._load_state_from_cache()
        if loaded:
            self._logger.debug("HostManager state reloaded from JetStream KV cache")

    async def _handle_host_message(self, data: dict):
        """Handle incoming host messages from router."""
        action = data.get("action")
        if action == "remove":
            host_id = data.get("host_id")
            if host_id:
                await self._remove_host_local(host_id)
            else:
                await self._reload_from_cache()
        elif action == "add":
            host_entry = data.get("host")
            if host_entry:
                await self._add_prepared_hosts_local([(host_entry["id"], host_entry["data"])])
            else:
                await self._reload_from_cache()
        else:
            await self._reload_from_cache()

    async def _publish(self, message: dict):
        """Publish host update message via global router."""
        await router.publish(MessageTopic.HOST, message)

    async def setup(self, db: AsyncSession):
        # Register handler with global router
        router.register_handler(MessageTopic.HOST, self._handle_host_message)

        # Initialize NATS if enabled
        if self._nats_enabled:
            self._nc, self._js, self._kv = await setup_nats_kv(self.KV_BUCKET_NAME)

        if await self._load_state_from_cache():
            return

        db_hosts = await get_hosts(db)
        await self.add_hosts(db, db_hosts)

    async def setup_local(self, db: AsyncSession):
        db_hosts = await get_hosts(db)
        await self._add_hosts_local(db, db_hosts)

    async def _reset_cache(self):
        await self.get_hosts.cache.clear()

    @staticmethod
    async def _prepare_host_entry(
        db: AsyncSession, host: BaseHost, inbounds_list: list[str]
    ) -> tuple[int, SubscriptionInboundData] | None:
        if host.is_disabled or (host.inbound_tag not in inbounds_list):
            return None

        # Handle downstream for xhttp
        downstream_data = None
        if (
            host.transport_settings
            and host.transport_settings.xhttp_settings
            and (ds_host := host.transport_settings.xhttp_settings.download_settings)
        ):
            downstream = await get_host_by_id(db, ds_host)
            if downstream:
                downstream_base = BaseHost.model_validate(downstream)
                downstream_data: SubscriptionInboundData = await _prepare_subscription_inbound_data(downstream_base)
        subscription_data = await _prepare_subscription_inbound_data(host, downstream_data)

        # Return subscription data directly
        return host.id, subscription_data

    async def add_host(self, db: AsyncSession, host: BaseHost):
        await self.add_hosts(db, [host])

    async def add_hosts(self, db: AsyncSession, hosts: list[BaseHost]):
        await self._add_hosts_impl(db, hosts)

    async def _add_prepared_hosts_local(self, prepared_hosts: list[tuple[int, SubscriptionInboundData | dict]]):
        async with self._lock:
            for host_id, host_data in prepared_hosts:
                self._hosts.pop(host_id, None)
                # Ensure we store SubscriptionInboundData models, not dicts
                if isinstance(host_data, dict):
                    self._hosts[host_id] = SubscriptionInboundData.model_validate(host_data)
                else:
                    self._hosts[host_id] = host_data
            await self._reset_cache()

    async def _add_hosts_local(self, db: AsyncSession, hosts: list[BaseHost]):
        serialized_hosts = [BaseHost.model_validate(host) for host in hosts]
        inbounds_list = await core_manager.get_inbounds()
        await upsert_inbounds(db, inbounds_list)
        await db.commit()

        prepared_hosts = []
        hosts_to_remove = []
        for host in serialized_hosts:
            result = await self._prepare_host_entry(db, host, inbounds_list)
            if result:
                prepared_hosts.append(result)
            else:
                hosts_to_remove.append(host.id)

        await self._add_prepared_hosts_local(prepared_hosts)

        async with self._lock:
            for host_id in hosts_to_remove:
                self._hosts.pop(host_id, None)

        await self._persist_state()

    async def _add_hosts_nats(self, db: AsyncSession, hosts: list[BaseHost]):
        serialized_hosts = [BaseHost.model_validate(host) for host in hosts]
        inbounds_list = await core_manager.get_inbounds()
        await upsert_inbounds(db, inbounds_list)
        await db.commit()

        prepared_hosts = []
        hosts_to_remove = []
        for host in serialized_hosts:
            result = await self._prepare_host_entry(db, host, inbounds_list)
            if result:
                prepared_hosts.append(result)
            else:
                hosts_to_remove.append(host.id)

        # Publish messages - all workers will process via listener
        for host_id, host_data in prepared_hosts:
            # Convert model to dict for JSON serialization
            serialized_data = host_data.model_dump()
            await self._publish({"action": "add", "host": {"id": host_id, "data": serialized_data}})
        for host_id in hosts_to_remove:
            await self._publish({"action": "remove", "host_id": host_id})

        # Keep local state in sync immediately, while still broadcasting via NATS.
        await self._add_prepared_hosts_local(prepared_hosts)
        async with self._lock:
            for host_id in hosts_to_remove:
                self._hosts.pop(host_id, None)

        # Persist state to NATS KV
        await self._persist_state()
        await self._reset_cache()

    async def remove_host(self, id: int):
        await self._remove_host_impl(id)

    async def _remove_host_local(self, id: int):
        async with self._lock:
            self._hosts.pop(id, None)
            await self._reset_cache()
        await self._persist_state()

    async def _remove_host_nats(self, id: int):
        await self._publish({"action": "remove", "host_id": id})
        await self._remove_host_local(id)

    async def get_host(self, id: int) -> dict | None:
        async with self._lock:
            host_data = self._hosts.get(id)
            if host_data is None:
                return None
            # Convert model to dict for API compatibility
            return host_data.model_dump() if isinstance(host_data, SubscriptionInboundData) else host_data

    @cached(ttl=10)
    async def get_hosts(self) -> dict[int, SubscriptionInboundData]:
        async with self._lock:
            # Return hosts sorted by priority (accessing from subscription_data model)
            sorted_hosts = dict(sorted(self._hosts.items(), key=lambda x: x[1].priority))
            return deepcopy(sorted_hosts)


host_manager: HostManager = HostManager()


@on_startup
async def initialize_hosts():
    if runtime_settings.role == Role.NODE:
        return
    async with GetDB() as db:
        await host_manager.setup(db)


@on_shutdown
async def shutdown_hosts():
    if runtime_settings.role == Role.NODE:
        return
    # Close NATS connection
    if host_manager._nc:
        await host_manager._nc.close()
