from __future__ import annotations

import base64
import json
from copy import deepcopy
from pathlib import PosixPath

import commentjson

from app.models.core import CoreType
from app.models.protocol import ProxyProtocol
from app.utils.crypto import get_cert_SANs, get_x25519_public_key, validate_mldsa65_seed, validate_mldsa65_verify


def _protocols_from_inbounds_by_tag(inbounds_by_tag: dict[str, dict]) -> frozenset[ProxyProtocol]:
    return frozenset(
        protocol
        for inbound in inbounds_by_tag.values()
        if (protocol := ProxyProtocol.from_value(inbound["protocol"])) is not None
    )


class XRayConfig(dict):
    def __init__(
        self,
        config: dict | str | PosixPath | None = None,
        exclude_inbound_tags: set[str] | None = None,
        fallbacks_inbound_tags: set[str] | None = None,
        skip_validation: bool = False,
    ):
        """Initialize the XRay config."""
        if config is None:
            config = {}
        if isinstance(config, str):
            # considering string as json
            config = commentjson.loads(config)

        if isinstance(config, dict):
            config = deepcopy(config)

        super().__init__(config)

        if exclude_inbound_tags is None:
            exclude_inbound_tags = set()
        if fallbacks_inbound_tags is None:
            fallbacks_inbound_tags = set()

        self._type = CoreType.xray
        exclude_inbound_tags.update(fallbacks_inbound_tags)
        self.exclude_inbound_tags = exclude_inbound_tags
        self.fallbacks_inbound_tags = set(fallbacks_inbound_tags)

        self._inbounds = []
        self._inbounds_by_tag = {}
        self._fallbacks_inbound = []
        self._protocols: frozenset[ProxyProtocol] = frozenset()

        # Registery pattern for network handlers, making it easy to add support for new network types in the future
        self.network_handlers = {
            "tcp": self._handle_tcp_raw_settings,
            "raw": self._handle_tcp_raw_settings,
            "ws": self._handle_ws_settings,
            "grpc": self._handle_grpc_settings,
            "gun": self._handle_grpc_settings,
            "quic": self._handle_quic_settings,
            "httpupgrade": self._handle_httpupgrade_settings,
            "splithttp": self._handle_xhttp_settings,
            "xhttp": self._handle_xhttp_settings,
            "kcp": self._handle_kcp_settings,
            "http": self._handle_http_settings,
            "h2": self._handle_http_settings,
            "h3": self._handle_http_settings,
        }
        self._collect_fallback_inbounds(fallbacks_inbound_tags)

        if skip_validation:
            return

        self._validate()
        self._resolve_inbounds()

    def _collect_fallback_inbounds(self, explicit_fallback_tags: set[str]):
        """Collect fallback parent inbounds.

        Supports manual fallback tag selection while also auto-detecting any
        inbound that defines `settings.fallbacks`.
        """
        fallback_tags = set(explicit_fallback_tags or set())
        for inbound in self.get("inbounds", []):
            if inbound.get("settings", {}).get("fallbacks", []):
                fallback_tags.add(inbound.get("tag", ""))

        for tag in fallback_tags:
            if not tag:
                continue
            inbound = self.get_inbound(tag)
            if inbound:
                self._fallbacks_inbound.append(inbound)

    def _validate(self):
        """Validate the config."""
        if not self.get("inbounds"):
            raise ValueError("config doesn't have inbounds")

        if not self.get("outbounds"):
            raise ValueError("config doesn't have outbounds")

        for inbound in self["inbounds"]:
            if not inbound.get("tag"):
                raise ValueError("all inbounds must have a unique tag")
            if "," in inbound.get("tag"):
                raise ValueError("character «,» is not allowed in inbound tag")
            if "<=>" in inbound.get("tag"):
                raise ValueError("character «<=>» is not allowed in inbound tag")
        for outbound in self["outbounds"]:
            if not outbound.get("tag"):
                raise ValueError("all outbounds must have a unique tag")

    def _find_fallback_inbound(self, inbound: dict) -> list:
        """Find fallback inbounds for an inbound."""
        fallback_inbounds = []
        for fallback in self._fallbacks_inbound:
            for fallback_settings in fallback.get("settings", {}).get("fallbacks", []):
                if fallback_settings.get("dest", "") == inbound.get("listen") or fallback_settings.get(
                    "dest", ""
                ) == inbound.get("port", 0):
                    fallback_inbounds.append(fallback)
        return fallback_inbounds

    def _create_base_settings(self, inbound: dict) -> dict:
        """Create base settings for an inbound."""
        settings = {
            "tag": inbound["tag"],
            "protocol": inbound["protocol"],
            "port": None,
            "network": "tcp",
            "tls": "none",
            "sni": [],
            "host": [],
            "path": "",
            "header_type": "",
            "is_fallback": False,
            "fallbacks": [],
            "finalmask": None,
        }
        return settings

    @staticmethod
    def _is_unix_socket(inbound: dict) -> bool:
        """Return True if the inbound listens on a Unix domain socket instead of a TCP/UDP port."""
        listen = inbound.get("listen", "")
        return isinstance(listen, str) and (listen.startswith(("/", "@")))

    def _handle_port_settings(self, inbound: dict, settings: dict):
        """Handle port settings for an inbound."""
        port_found = True
        try:
            settings["port"] = inbound["port"]
        except KeyError:
            port_found = False

        is_unix_socket = self._is_unix_socket(inbound)

        if self._fallbacks_inbound and "<=>" not in inbound["tag"]:
            if inbound.get("settings", {}).get("fallbacks", []):
                if not port_found and not is_unix_socket:
                    raise ValueError(f"{settings['tag']} inbound doesn't have port")
                return
            fallbacks = self._find_fallback_inbound(inbound)
            if fallbacks:
                settings["is_fallback"] = True
                settings["fallbacks"] = fallbacks
                return

        if not port_found and not is_unix_socket:
            raise ValueError(f"{settings['tag']} inbound doesn't have port")

    def _handle_tls_settings(self, tls_settings: dict, settings: dict, inbound_tag: str):
        """Handle TLS security settings."""
        settings["tls"] = "tls"
        settings["pinnedPeerCertSha256"] = tls_settings.get("pinnedPeerCertSha256", "")
        settings["fp"] = tls_settings.get("fingerprint", "chrome")
        if sni := tls_settings.get("serverName"):
            settings["sni"].append(str(sni))
        for certificate in tls_settings.get("certificates", []):
            serve_on_node = certificate.pop("serveOnNode", False)
            if serve_on_node:
                # prevent error on parse by xray core
                continue
            if certificate.get("certificateFile", None):
                with open(certificate["certificateFile"], "rb") as file:
                    cert = file.read()
                    settings["sni"].extend(get_cert_SANs(cert))

                if certificate.get("keyFile", None):
                    with open(certificate["keyFile"], "rb") as file:
                        key = file.read()
                else:
                    raise ValueError(f"{inbound_tag} inbound doesn't keyFile in tlsSettings")

                certificate["certificate"] = [line.decode() for line in cert.splitlines()]
                certificate["key"] = [line.decode() for line in key.splitlines()]

                del certificate["certificateFile"]
                del certificate["keyFile"]

            elif certificate.get("certificate", None):
                cert = certificate["certificate"]
                if isinstance(cert, list):
                    cert = "\n".join(cert)
                if isinstance(cert, str):
                    cert = cert.encode()
                settings["sni"].extend(get_cert_SANs(cert))

        return tls_settings

    def _handle_reality_settings(self, tls_settings: dict, settings: dict, inbound_tag: str):
        """Handle Reality security settings."""
        settings["fp"] = tls_settings.get("fingerprint", "chrome")
        settings["tls"] = "reality"
        settings["sni"] = [str(sni) for sni in (tls_settings.get("serverNames") or [])]

        pvk = tls_settings.get("privateKey")
        if not pvk:
            raise ValueError(f"You need to provide privateKey in realitySettings of {inbound_tag}")

        settings["pbk"] = get_x25519_public_key(pvk)
        if not settings.get("pbk"):
            raise ValueError(f"You need to provide publicKey in realitySettings of {inbound_tag}")

        try:
            settings["sids"] = tls_settings.get("shortIds")
            settings["sids"][0]  # check if there is any shortIds
        except IndexError, TypeError:
            raise ValueError(f"You need to define at least one shortID in realitySettings of {inbound_tag}")
        try:
            settings["spx"] = tls_settings.get("spiderX")
        except Exception:
            settings["spx"] = ""

        mldsa65_seed = tls_settings.get("mldsa65Seed")
        mldsa65_verify = tls_settings.get("mldsa65Verify")
        seed_set = isinstance(mldsa65_seed, str) and bool(mldsa65_seed.strip())
        verify_set = isinstance(mldsa65_verify, str) and bool(mldsa65_verify.strip())

        if seed_set or verify_set:
            # Client pqv without a matching server seed causes silent REALITY auth failure.
            if verify_set and not seed_set:
                raise ValueError(
                    f"mldsa65Verify is set without mldsa65Seed in realitySettings of {inbound_tag}. "
                    "Set both (matching pair) or clear both."
                )
            if seed_set:
                validate_mldsa65_seed(mldsa65_seed)
            if verify_set:
                settings["mldsa65Verify"] = validate_mldsa65_verify(mldsa65_verify)
            else:
                # Seed-only is valid (server signs; clients without pqv still connect).
                settings["mldsa65Verify"] = None
        else:
            settings["mldsa65Verify"] = None

    def _handle_network_settings(self, net: str, net_settings: dict, settings: dict, inbound_tag: str):
        """Handle network-specific settings."""
        handler = self.network_handlers.get(net, self._handle_default_network_settings)
        handler(net_settings, settings, inbound_tag)

    def _handle_tcp_raw_settings(self, net_settings: dict, settings: dict, inbound_tag: str):
        """Handle TCP and RAW network settings."""
        header = net_settings.get("header", {})
        request = header.get("request", {})
        path = request.get("path")
        host = request.get("headers", {}).get("Host")

        settings["header_type"] = header.get("type", "none")

        if isinstance(path, str) or isinstance(host, str):
            raise TypeError(
                f"Settings of {inbound_tag} for path and host must be list, not str\n"
                "https://xtls.github.io/config/transports/tcp.html#httpheaderobject"
            )

        if path and isinstance(path, list):
            settings["path"] = path[0]

        if host and isinstance(host, list):
            settings["host"] = host

    def _handle_ws_settings(self, net_settings: dict, settings: dict, inbound_tag: str = ""):
        """Handle WebSocket network settings."""
        path = net_settings.get("path", "")
        host = net_settings.get("host", "") or net_settings.get("headers", {}).get("Host")

        settings["header_type"] = ""

        if isinstance(path, list) or isinstance(host, list):
            raise TypeError(
                "Settings for path and host must be str, not list\n"
                "https://xtls.github.io/config/transports/websocket.html#websocketobject"
            )

        if isinstance(path, str):
            settings["path"] = path

        if isinstance(host, str):
            settings["host"] = [host]

    def _handle_grpc_settings(self, net_settings: dict, settings: dict, inbound_tag: str = ""):
        """Handle gRPC network settings."""
        settings["header_type"] = ""
        settings["path"] = net_settings.get("serviceName", "")
        host = net_settings.get("authority", "")
        settings["host"] = [host]

    def _handle_quic_settings(self, net_settings: dict, settings: dict, inbound_tag: str = ""):
        """Handle QUIC network settings."""
        settings["header_type"] = net_settings.get("header", {}).get("type", "")
        settings["path"] = net_settings.get("key", "")
        settings["host"] = [net_settings.get("security", "")]

    def _handle_httpupgrade_settings(self, net_settings: dict, settings: dict, inbound_tag: str = ""):
        """Handle HTTP Upgrade network settings."""
        settings["path"] = net_settings.get("path", "")
        host = net_settings.get("host", "")
        settings["host"] = [host]

    def _handle_xhttp_settings(self, net_settings: dict, settings: dict, inbound_tag: str = ""):
        """Handle XHTTP network settings."""
        extra = net_settings.get("extra")
        has_extra = isinstance(extra, dict)
        if not has_extra:
            extra = {}

        def get_xhttp_value(key: str):
            if has_extra:
                return extra.get(key)
            return net_settings.get(key)

        settings["path"] = net_settings.get("path", "")
        host = net_settings.get("host", "")
        settings["host"] = [host]
        settings["mode"] = net_settings.get("mode", "auto")
        settings["no_grpc_header"] = get_xhttp_value("noGRPCHeader")
        settings["sc_max_each_post_bytes"] = get_xhttp_value("scMaxEachPostBytes")
        settings["sc_min_posts_interval_ms"] = get_xhttp_value("scMinPostsIntervalMs")
        settings["x_padding_bytes"] = get_xhttp_value("xPaddingBytes")
        settings["x_padding_obfs_mode"] = get_xhttp_value("xPaddingObfsMode")
        settings["x_padding_key"] = get_xhttp_value("xPaddingKey")
        settings["x_padding_header"] = get_xhttp_value("xPaddingHeader")
        settings["x_padding_placement"] = get_xhttp_value("xPaddingPlacement")
        settings["x_padding_method"] = get_xhttp_value("xPaddingMethod")
        settings["uplink_http_method"] = get_xhttp_value("uplinkHTTPMethod")
        session_id_placement = get_xhttp_value("sessionIDPlacement")
        settings["session_placement"] = (
            session_id_placement if session_id_placement else get_xhttp_value("sessionPlacement")
        )
        session_id_key = get_xhttp_value("sessionIDKey")
        settings["session_key"] = session_id_key if session_id_key else get_xhttp_value("sessionKey")
        settings["session_id_table"] = get_xhttp_value("sessionIDTable")
        settings["session_id_length"] = get_xhttp_value("sessionIDLength")
        settings["seq_placement"] = get_xhttp_value("seqPlacement")
        settings["seq_key"] = get_xhttp_value("seqKey")
        settings["uplink_data_placement"] = get_xhttp_value("uplinkDataPlacement")
        settings["uplink_data_key"] = get_xhttp_value("uplinkDataKey")
        settings["uplink_chunk_size"] = get_xhttp_value("uplinkChunkSize")
        settings["xmux"] = get_xhttp_value("xmux")
        settings["download_settings"] = get_xhttp_value("downloadSettings")

        headers = get_xhttp_value("headers")
        if isinstance(headers, dict):
            settings["http_headers"] = {k: v for k, v in headers.items() if isinstance(k, str) and isinstance(v, str)}

    def _handle_kcp_settings(self, net_settings: dict, settings: dict, inbound_tag: str = ""):
        """Handle KCP network settings."""
        settings["mtu"] = net_settings.get("mtu")
        settings["tti"] = net_settings.get("tti")
        settings["uplink_capacity"] = net_settings.get("uplinkCapacity")
        settings["downlink_capacity"] = net_settings.get("downlinkCapacity")
        settings["congestion"] = net_settings.get("congestion")
        settings["read_buffer_size"] = net_settings.get("readBufferSize")
        settings["write_buffer_size"] = net_settings.get("writeBufferSize")

    def _handle_http_settings(self, net_settings: dict, settings: dict, inbound_tag: str = ""):
        """Handle HTTP network settings."""
        settings["host"] = net_settings.get("host") or net_settings.get("Host", "")
        settings["path"] = net_settings.get("path", "")

    def _handle_default_network_settings(self, net_settings: dict, settings: dict, inbound_tag: str = ""):
        """Handle default network settings."""
        settings["path"] = net_settings.get("path", "")
        host = net_settings.get("host", {}) or net_settings.get("Host", {})
        if host and isinstance(host, str):
            settings["host"] = host
        elif host and isinstance(host, list):
            settings["host"] = host[0]

    @staticmethod
    def _hysteria_finalmask_from_stream(stream: dict, net_settings: dict) -> dict | None:
        """Normalize Hysteria Salamander masks into finalmask for client generation."""
        finalmask = stream.get("finalmask") or stream.get("finalMask")
        if isinstance(finalmask, dict):
            finalmask = deepcopy(finalmask)
        else:
            finalmask = {}

        udpmasks = None
        if isinstance(net_settings, dict):
            udpmasks = net_settings.get("udpmasks")
        if not isinstance(udpmasks, list):
            udpmasks = stream.get("udpmasks")

        if isinstance(udpmasks, list) and udpmasks and not finalmask.get("udp"):
            finalmask["udp"] = deepcopy(udpmasks)

        return finalmask or None

    def _handle_shadowsocks_settings(self, inbound_settings: dict, settings: dict):
        """Handle shadowsocks special settings."""
        settings["method"] = inbound_settings.get("method", "")
        if settings["method"] == "2022-blake3-chacha20-poly1305":
            raise ValueError("only 2022-blake3-aes-*-gcm methods are supported")
        if settings["method"].startswith("2022-blake3"):
            settings["is_2022"] = True
            password = inbound_settings.get("password", "")

            # Validate if password is a valid base64 string
            try:
                base64.b64decode(password, validate=True)
                settings["password"] = password
            except Exception:
                raise ValueError("Shadowsocks password must be a valid base64 string")
        else:
            settings["is_2022"] = False
        settings["header_type"] = "none"

    def _resolve_inbounds(self):
        """Resolve all inbounds and their settings."""
        for inbound in self["inbounds"]:
            self._read_inbound(inbound)
        self._protocols = _protocols_from_inbounds_by_tag(self._inbounds_by_tag)

    def _read_inbound(self, inbound: dict):
        """Read an inbound and its settings."""
        if inbound["protocol"] not in ("vmess", "vless", "trojan", "shadowsocks", "hysteria"):
            return

        if inbound["tag"] in self.exclude_inbound_tags:
            return

        if not inbound.get("settings"):
            inbound["settings"] = {}
        if not inbound["settings"].get("clients"):
            inbound["settings"]["clients"] = []

        settings = self._create_base_settings(inbound)
        self._handle_port_settings(inbound, settings)

        if inbound["protocol"] == "vless":
            settings["flow"] = inbound.get("settings").get("flow", "")
            vless_decryption = inbound.get("settings").get("decryption", "none")
            vless_encryption = inbound.get("settings").get("encryption", "none")
            if vless_decryption != "none" and vless_encryption in ("", "none", None):
                raise ValueError(f"'encryption' key must be provided in {inbound['tag']} inbound")
            settings["encryption"] = vless_encryption

        if inbound["protocol"] == "shadowsocks":
            self._handle_shadowsocks_settings(inbound["settings"], settings)

        if stream := inbound.get("streamSettings"):
            method = stream.get("method")
            net = method if method else stream.get("network", "tcp")
            net_settings = stream.get(f"{net}Settings", {})
            security = stream.get("security")
            tls_settings = stream.get(f"{security}Settings")

            if inbound["protocol"] == "hysteria" and security != "tls":
                raise ValueError(f"{inbound['tag']} hysteria inbound requires TLS")

            if settings["is_fallback"] is True:
                for fallback in settings["fallbacks"]:
                    fallback_tag = f"{inbound['tag']}<=>{fallback['tag']}"  # Fake inbound tag
                    if fallback_tag in self._inbounds_by_tag:
                        continue
                    try:
                        fallback_port = fallback["port"]
                    except KeyError:
                        raise ValueError("fallbacks inbound doesn't have port")
                    fallback_security = fallback.get("streamSettings", {}).get("security")
                    fallback_tls_settings = fallback.get("streamSettings", {}).get(f"{fallback_security}Settings", {})
                    fallback_inbound = self._make_fallback_inbound(
                        deepcopy(inbound), fallback_security, fallback_tls_settings, fallback_tag, fallback_port
                    )
                    self._read_inbound(fallback_inbound)

            settings["network"] = net

            if security == "tls":
                stream["tlsSettings"] = self._handle_tls_settings(tls_settings, settings, inbound["tag"])
            elif security == "reality":
                self._handle_reality_settings(tls_settings, settings, inbound["tag"])

            self._handle_network_settings(net, net_settings, settings, inbound["tag"])

            finalmask = stream.get("finalmask") or stream.get("finalMask")
            if net == "hysteria":
                finalmask = self._hysteria_finalmask_from_stream(stream, net_settings)
            if finalmask is not None:
                settings["finalmask"] = finalmask

        if inbound["tag"] not in self._inbounds:
            self._inbounds.append(inbound["tag"])
            self._inbounds_by_tag[inbound["tag"]] = settings

    def _make_fallback_inbound(
        self,
        inbound: dict,
        security: str,
        tls_settings: dict,
        inbound_tag: str,
        port: int | str,
    ):
        """Make a fallback inbound."""
        fallback_inbound = {
            **inbound,
            "port": port,
            "tag": inbound_tag,
        }
        fallback_inbound["streamSettings"]["security"] = security
        fallback_inbound["streamSettings"][f"{security}Settings"] = tls_settings
        return fallback_inbound

    def get_inbound(self, tag) -> dict:
        """Get an inbound by tag."""
        for inbound in self["inbounds"]:
            if inbound["tag"] == tag:
                return inbound

    def get_outbound(self, tag) -> dict:
        """Get an outbound by tag."""
        for outbound in self["outbounds"]:
            if outbound["tag"] == tag:
                return outbound

    def to_str(self, **json_kwargs) -> str:
        """Convert the config to a JSON string."""
        return json.dumps(self, **json_kwargs)

    @property
    def inbounds_by_tag(self) -> dict:
        """Get inbounds by tag."""
        return self._inbounds_by_tag

    @property
    def inbounds(self) -> list[str]:
        """Get inbounds by tag."""
        return self._inbounds

    @property
    def protocols(self) -> frozenset[ProxyProtocol]:
        return self._protocols

    @property
    def type(self) -> str:
        return self._type

    def to_json(self) -> dict:
        """Convert the config to a JSON-serializable dictionary."""
        return {
            "type": self.type,
            "config": dict(self),
            "exclude_inbound_tags": list(self.exclude_inbound_tags),
            "fallbacks_inbound_tags": list(self.fallbacks_inbound_tags),
            "inbounds": self.inbounds,
            "inbounds_by_tag": self.inbounds_by_tag,
        }

    @classmethod
    def from_json(cls, data: dict) -> XRayConfig:
        """Reconstruct the config from a dictionary."""
        fallback_tags = data.get("fallbacks_inbound_tags")
        if fallback_tags is None:
            fallback_tags = []

        instance = cls(
            config=data.get("config", {}),
            exclude_inbound_tags=set(data.get("exclude_inbound_tags", [])),
            fallbacks_inbound_tags=set(fallback_tags),
            skip_validation=True,
        )
        if "inbounds" in data:
            instance._inbounds = data["inbounds"]
        if "inbounds_by_tag" in data:
            instance._inbounds_by_tag = data["inbounds_by_tag"]
        instance._protocols = _protocols_from_inbounds_by_tag(instance._inbounds_by_tag)
        return instance

    def copy(self):
        """Copy the config."""
        return deepcopy(self)
