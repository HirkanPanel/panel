import { cn } from '@/lib/utils'
import { Slot } from '@radix-ui/react-slot'
import { cva, type VariantProps } from 'class-variance-authority'
import { LoaderCircleIcon } from 'lucide-react'
import * as React from 'react'

const buttonVariants = cva(
  'inline-flex cursor-pointer items-center justify-center gap-1 whitespace-nowrap rounded-lg text-sm font-medium transition-[background-color,box-shadow,transform] duration-150 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring disabled:pointer-events-none disabled:cursor-not-allowed disabled:opacity-50 active:scale-[0.98]',
  {
    variants: {
      variant: {
        default: 'bg-primary text-primary-foreground hover:bg-primary/90',
        destructive: 'bg-destructive text-destructive-foreground hover:bg-destructive/90',
        outline: 'border border-border bg-background hover:bg-accent hover:text-accent-foreground dark:border-input',
        secondary: 'bg-secondary text-secondary-foreground hover:bg-secondary/80',
        ghost: 'hover:bg-accent hover:text-accent-foreground',
        link: 'text-primary underline-offset-4 hover:underline',
      },
      size: {
        default: 'h-10 px-4 py-2',
        sm: 'h-9 rounded-md px-3 [&>svg]:w-5 [&>svg]:h-5',
        lg: 'h-11 rounded-md px-8',
        icon: 'h-7 w-7 [&>svg]:w-4 [&>svg]:h-4 [&>svg]:stroke-[1.5px] rounded-sm',
        'icon-md': 'h-9 w-9 [&>svg]:w-4 [&>svg]:h-4 [&>svg]:stroke-[1.5px] rounded-md',
      },
    },
    defaultVariants: {
      variant: 'default',
      size: 'default',
    },
  },
)

export interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement>, VariantProps<typeof buttonVariants> {
  asChild?: boolean
  isLoading?: boolean
  loadingText?: string
}

const Button = React.forwardRef<HTMLButtonElement, ButtonProps>(({ className, variant, size, asChild = false, isLoading = false, loadingText, children, ...rest }, ref) => {
  const Comp = isLoading ? 'button' : asChild ? Slot : 'button'
  const content = isLoading ? (
    <>
      <LoaderCircleIcon className="h-5 w-5 animate-spin" />
      {loadingText}
    </>
  ) : (
    children
  )
  return (
    <Comp className={cn(buttonVariants({ variant, size, className }))} ref={ref} {...rest}>
      {content}
    </Comp>
  )
})
Button.displayName = 'Button'

export { Button, buttonVariants }
