import os
from datetime import UTC, datetime as dt
from enum import Enum
from typing import Any

from sqlalchemy import (
    JSON,
    BigInteger,
    Column,
    DateTime,
    Enum as SQLEnum,
    Float,
    ForeignKey,
    Index,
    String,
    Table,
    Text,
    UniqueConstraint,
    and_,
    case,
    event,
    func,
    or_,
)
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.ext.asyncio import async_object_session
from sqlalchemy.ext.hybrid import hybrid_property
from sqlalchemy.orm import Mapped, mapped_column, query_expression, relationship
from sqlalchemy.sql.expression import select, text

from app.db.base import Base
from app.db.compiles_types import CaseSensitiveString, DaysDiff, EnumArray, SqliteCompatibleBigInteger, StringArray

PostgresJSONB = JSON().with_variant(JSONB(none_as_null=True), "postgresql")


def fk_id_column(target: str, **column_kwargs: Any):
    fk_kwargs = {key: column_kwargs.pop(key) for key in ("ondelete", "onupdate") if key in column_kwargs}
    return mapped_column(SqliteCompatibleBigInteger, ForeignKey(target, **fk_kwargs), **column_kwargs)


def fk_id_table_column(name: str, target: str, **column_kwargs: Any):
    fk_kwargs = {key: column_kwargs.pop(key) for key in ("ondelete", "onupdate") if key in column_kwargs}
    return Column(name, SqliteCompatibleBigInteger, ForeignKey(target, **fk_kwargs), **column_kwargs)


inbounds_groups_association = Table(
    "inbounds_groups_association",
    Base.metadata,
    fk_id_table_column("inbound_id", "inbounds.id", primary_key=True),
    fk_id_table_column("group_id", "groups.id", primary_key=True),
)

users_groups_association = Table(
    "users_groups_association",
    Base.metadata,
    fk_id_table_column("user_id", "users.id", primary_key=True),
    fk_id_table_column("groups_id", "groups.id", primary_key=True),
)


class AdminStatus(str, Enum):
    active = "active"
    disabled = "disabled"
    limited = "limited"


class IdMixin:
    id: Mapped[int] = mapped_column(SqliteCompatibleBigInteger, primary_key=True, init=False, autoincrement=True)


class CreatedAtUTCMixin(IdMixin):
    created_at: Mapped[dt] = mapped_column(DateTime(timezone=True), default_factory=lambda: dt.now(UTC), init=False)


class Admin(Base, CreatedAtUTCMixin):
    __tablename__ = "admins"
    username: Mapped[str] = mapped_column(String(34), unique=True, index=True)
    hashed_password: Mapped[str] = mapped_column(String(128))
    users: Mapped[list[User]] = relationship(back_populates="admin", init=False, default_factory=list)
    usage_logs: Mapped[list[AdminUsageLogs]] = relationship(
        back_populates="admin", init=False, default_factory=list, cascade="all, delete-orphan"
    )
    notification_reminders: Mapped[list[AdminNotificationReminder]] = relationship(
        back_populates="admin", init=False, default_factory=list, cascade="all, delete-orphan"
    )
    api_keys: Mapped[list[APIKey]] = relationship(
        back_populates="admin", init=False, default_factory=list, cascade="all, delete-orphan"
    )

    password_reset_at: Mapped[dt | None] = mapped_column(DateTime(timezone=True), default=None)
    telegram_id: Mapped[int | None] = mapped_column(BigInteger, default=None)
    discord_webhook: Mapped[str | None] = mapped_column(String(1024), default=None)
    used_traffic: Mapped[int] = mapped_column(BigInteger, default=0)
    data_limit: Mapped[int | None] = mapped_column(BigInteger, default=None)
    status: Mapped[AdminStatus] = mapped_column(
        SQLEnum(AdminStatus, name="adminstatus", create_constraint=True),
        default=AdminStatus.active,
        server_default="active",
    )
    last_status_change: Mapped[dt | None] = mapped_column(DateTime(timezone=True), default=None)
    sub_template: Mapped[str | None] = mapped_column(String(1024), default=None)
    sub_domain: Mapped[str | None] = mapped_column(String(256), default=None)
    profile_title: Mapped[str | None] = mapped_column(String(512), default=None)
    support_url: Mapped[str | None] = mapped_column(String(1024), default=None)
    custom_variables: Mapped[list[dict[str, str]] | None] = mapped_column(PostgresJSONB, default=None)
    notification_enable: Mapped[dict | None] = mapped_column(PostgresJSONB, default=None)
    note: Mapped[str | None] = mapped_column(String(500), default=None)
    role_id: Mapped[int] = fk_id_column("admin_roles.id", default=0)
    role: Mapped[AdminRole | None] = relationship(back_populates="admins", init=False, lazy="select")
    permission_overrides: Mapped[dict | None] = mapped_column(PostgresJSONB, default=None)

    @hybrid_property
    def is_disabled(self) -> bool:
        """Backward-compat property — True when status is disabled."""
        return self.status == AdminStatus.disabled

    @is_disabled.expression
    def is_disabled(cls):
        return cls.status == AdminStatus.disabled

    @hybrid_property
    def is_limited(self) -> bool:
        """True when status is limited."""
        return self.status == AdminStatus.limited

    @is_limited.expression
    def is_limited(cls):
        return cls.status == AdminStatus.limited

    @hybrid_property
    def reseted_usage(self) -> int:
        return int(sum([log.used_traffic_at_reset for log in self.usage_logs]))

    @reseted_usage.expression
    def reseted_usage(cls):
        return (
            select(func.sum(AdminUsageLogs.used_traffic_at_reset))
            .where(AdminUsageLogs.admin_id == cls.id)
            .label("reseted_usage")
        )

    @property
    def lifetime_used_traffic(self) -> int:
        return self.reseted_usage + self.used_traffic

    @property
    def users_sync_blocked(self) -> bool:
        """True when this admin's users should NOT be synced to nodes."""
        return (self.status == AdminStatus.limited and self.role.disconnect_users_when_limited) or (
            self.status == AdminStatus.disabled and self.role.disconnect_users_when_disabled
        )

    @property
    def total_users(self) -> int:
        return len(self.users)

    @property
    def has_api_keys(self) -> bool:
        """True when the admin owns at least one API key."""
        return len(self.api_keys) > 0


class AdminUsageLogs(Base, IdMixin):
    __tablename__ = "admin_usage_logs"
    admin_id: Mapped[int] = fk_id_column("admins.id")
    admin: Mapped[Admin] = relationship(back_populates="usage_logs", init=False)
    used_traffic_at_reset: Mapped[int] = mapped_column(BigInteger, nullable=False)
    reset_at: Mapped[dt] = mapped_column(DateTime(timezone=True), default=lambda: dt.now(UTC), init=False)


class ReminderType(str, Enum):
    expiration_date = "expiration_date"
    data_usage = "data_usage"


class UserStatus(str, Enum):
    active = "active"
    disabled = "disabled"
    limited = "limited"
    expired = "expired"
    on_hold = "on_hold"


class DataLimitResetStrategy(str, Enum):
    no_reset = "no_reset"
    day = "day"
    week = "week"
    month = "month"
    year = "year"


class User(Base, CreatedAtUTCMixin):
    __tablename__ = "users"
    __table_args__ = (
        Index("idx_users_admin_online", "admin_id", "online_at"),
        Index("idx_users_admin_status", "admin_id", "status"),
        Index("idx_users_admin_created", "admin_id", "created_at"),
    )
    username: Mapped[str] = mapped_column(CaseSensitiveString(128), unique=True, index=True)
    node_usages: Mapped[list[NodeUserUsage]] = relationship(
        back_populates="user",
        cascade="all, delete-orphan",
        init=False,
    )
    notification_reminders: Mapped[list[NotificationReminder]] = relationship(
        back_populates="user", cascade="all, delete-orphan", init=False
    )
    subscription_updates: Mapped[list[UserSubscriptionUpdate]] = relationship(
        back_populates="user", cascade="all, delete-orphan", init=False
    )
    usage_logs: Mapped[list[UserUsageResetLogs]] = relationship(back_populates="user", init=False)
    admin: Mapped[Admin] = relationship(back_populates="users", init=False)
    next_plan: Mapped[NextPlan | None] = relationship(
        uselist=False, back_populates="user", cascade="all, delete-orphan", init=False
    )
    hwids: Mapped[list[UserHWID]] = relationship(back_populates="user", cascade="all, delete-orphan", init=False)
    groups: Mapped[list[Group]] = relationship(secondary=users_groups_association, back_populates="users", init=False)
    proxy_settings: Mapped[dict[str, Any]] = mapped_column(
        JSON(True), server_default=text("'{}'"), default_factory=dict
    )
    status: Mapped[UserStatus] = mapped_column(SQLEnum(UserStatus), default=UserStatus.active)
    used_traffic: Mapped[int] = mapped_column(BigInteger, default=0)
    data_limit: Mapped[int | None] = mapped_column(BigInteger, default=None)
    data_limit_reset_strategy: Mapped[DataLimitResetStrategy] = mapped_column(
        SQLEnum(DataLimitResetStrategy),
        default=DataLimitResetStrategy.no_reset,
    )
    _expire: Mapped[dt | None] = mapped_column("expire", DateTime(timezone=True), default=None, init=False)
    admin_id: Mapped[int | None] = fk_id_column("admins.id", default=None)
    sub_revoked_at: Mapped[dt | None] = mapped_column(DateTime(timezone=True), default=None)
    note: Mapped[str | None] = mapped_column(String(500), default=None)
    online_at: Mapped[dt | None] = mapped_column(DateTime(timezone=True), default=None)
    on_hold_expire_duration: Mapped[int | None] = mapped_column(BigInteger, default=None)
    on_hold_timeout: Mapped[dt | None] = mapped_column(DateTime(timezone=True), default=None)
    auto_delete_in_days: Mapped[int | None] = mapped_column(default=None)
    hwid_limit: Mapped[int | None] = mapped_column(BigInteger, default=None)
    edit_at: Mapped[dt | None] = mapped_column(DateTime(timezone=True), default=None)
    last_status_change: Mapped[dt | None] = mapped_column(DateTime(timezone=True), default=None)
    _reseted_usage_query: Mapped[int | None] = query_expression(repr=False)

    @hybrid_property
    def expire(self) -> dt | None:
        if self._expire and self._expire.tzinfo is None:
            return self._expire.replace(tzinfo=UTC)
        return self._expire

    @expire.inplace.expression
    def expire(cls):
        return cls._expire

    @expire.setter
    def expire(self, value: dt | None):
        if value is None:
            self._expire = None
            return
        if value.tzinfo is None:
            self._expire = value.replace(tzinfo=UTC)
            return
        self._expire = value.astimezone(UTC)

    @hybrid_property
    def reseted_usage(self) -> int:
        expr = self.__dict__.get("_reseted_usage_query")
        if expr is None:
            expr = self._reseted_usage_query
        if expr is not None:
            return int(expr)
        usage_logs = self.__dict__.get("usage_logs")
        if usage_logs is None:
            return 0
        return int(sum(log.used_traffic_at_reset for log in usage_logs))

    @reseted_usage.expression
    def reseted_usage(cls):
        return (
            select(func.sum(UserUsageResetLogs.used_traffic_at_reset))
            .where(UserUsageResetLogs.user_id == cls.id)
            .label("reseted_usage")
        )

    @property
    def lifetime_used_traffic(self) -> int:
        return self.reseted_usage + self.used_traffic

    @property
    def last_traffic_reset_time(self):
        return self.usage_logs[-1].reset_at if self.usage_logs else self.created_at

    async def inbounds(self) -> list[str]:
        """Returns a flat list of all included inbound tags for enabled groups."""
        loaded_groups = self.__dict__.get("groups")
        if loaded_groups is not None:
            inbound_tags: set[str] = set()
            inbounds_loaded = True
            for group in loaded_groups:
                if "inbounds" not in group.__dict__:
                    inbounds_loaded = False
                    break
                if group.is_disabled:
                    continue
                for inbound in group.__dict__.get("inbounds") or []:
                    inbound_tags.add(inbound.tag)
            if inbounds_loaded:
                return list(inbound_tags)

        session = async_object_session(self)
        if session is not None:
            stmt = (
                select(ProxyInbound.tag)
                .select_from(users_groups_association)
                .join(Group, users_groups_association.c.groups_id == Group.id)
                .join(inbounds_groups_association, Group.id == inbounds_groups_association.c.group_id)
                .join(ProxyInbound, inbounds_groups_association.c.inbound_id == ProxyInbound.id)
                .where(users_groups_association.c.user_id == self.id, Group.is_disabled.is_(False))
                .distinct()
            )
            result = await session.execute(stmt)
            return list(result.scalars().all())

        # Fallback for detached instances: use already-loaded attrs only.
        included_tags = set()
        for group in loaded_groups or []:
            if group.is_disabled:
                continue
            for inbound in group.__dict__.get("inbounds") or []:
                included_tags.add(inbound.tag)
        return list(included_tags)

    @property
    def group_ids(self):
        groups = self.__dict__.get("groups")
        if groups is None:
            return []
        return [group.id for group in groups]

    @property
    def group_names(self):
        groups = self.__dict__.get("groups")
        if groups is None:
            return []
        return [group.name for group in groups]

    @hybrid_property
    def is_expired(self) -> bool:
        return self.expire is not None and self.expire <= dt.now(UTC)

    @is_expired.expression
    def is_expired(cls):
        return and_(cls.expire.isnot(None), cls.expire <= func.current_timestamp())

    @hybrid_property
    def is_limited(self) -> bool:
        return self.data_limit is not None and self.data_limit > 0 and self.data_limit <= self.used_traffic

    @is_limited.expression
    def is_limited(cls):
        return and_(cls.data_limit.isnot(None), cls.data_limit > 0, cls.data_limit <= cls.used_traffic)

    @hybrid_property
    def become_online(self) -> bool:
        now = dt.now(UTC)

        # Check if online_at is set and greater than or equal to base time
        if self.online_at:
            base_time = (self.edit_at or self.created_at).replace(tzinfo=UTC)
            return self.online_at.replace(tzinfo=UTC) >= base_time

        # Check if on_hold_timeout has passed
        return bool(self.on_hold_timeout and self.on_hold_timeout.replace(tzinfo=UTC) <= now)

    @become_online.expression
    def become_online(cls):
        now = func.current_timestamp()
        base_time = case((cls.edit_at.isnot(None), cls.edit_at), else_=cls.created_at)

        return or_(
            # online_at condition
            and_(cls.online_at.isnot(None), cls.online_at >= base_time),
            # on_hold_timeout condition
            and_(cls.online_at.is_(None), cls.on_hold_timeout.isnot(None), cls.on_hold_timeout <= now),
        )

    @hybrid_property
    def usage_percentage(self) -> float:
        if not self.data_limit or self.data_limit == 0:
            return 0.0
        return (self.used_traffic * 100) / self.data_limit

    @usage_percentage.expression
    def usage_percentage(cls):
        return case(
            (and_(cls.data_limit.isnot(None), cls.data_limit > 0), (cls.used_traffic * 100.0) / cls.data_limit),
            else_=0.0,
        )

    @hybrid_property
    def days_left(self) -> int:
        if not self.expire:
            return 0
        remaining_days = (self.expire.replace(tzinfo=UTC) - dt.now(UTC)).days
        return max(remaining_days, 0)

    @days_left.expression
    def days_left(cls):
        return case((cls.expire.isnot(None), func.floor(DaysDiff(cls.expire))), else_=0)


class UserSubscriptionUpdate(Base, CreatedAtUTCMixin):
    __tablename__ = "user_subscription_updates"
    __table_args__ = (
        Index("idx_user_subscription_updates_user_id", "user_id"),
        Index("idx_user_subscription_updates_user_created", "user_id", "created_at"),
    )
    user_id: Mapped[int] = fk_id_column("users.id", ondelete="CASCADE")
    user: Mapped[User] = relationship(back_populates="subscription_updates", init=False)
    user_agent: Mapped[str] = mapped_column(String(512))
    ip: Mapped[str | None] = mapped_column(String(64), nullable=True, default=None)
    hwid: Mapped[str | None] = mapped_column(String(256), nullable=True, default=None)


class UserHWID(Base, CreatedAtUTCMixin):
    __tablename__ = "user_hwids"
    __table_args__ = (
        UniqueConstraint("user_id", "hwid"),
        Index("ix_user_hwids_user_id", "user_id"),
        Index("ix_user_hwids_hwid", "hwid"),
        Index("ix_user_hwids_created_at", "created_at"),
        Index("ix_user_hwids_last_used_at", "last_used_at"),
    )
    user_id: Mapped[int] = fk_id_column("users.id", ondelete="CASCADE")
    user: Mapped[User] = relationship(back_populates="hwids", init=False)
    hwid: Mapped[str] = mapped_column(String(256), nullable=False)
    device_os: Mapped[str | None] = mapped_column(String(256), default=None)
    os_version: Mapped[str | None] = mapped_column(String(128), default=None)
    device_model: Mapped[str | None] = mapped_column(String(256), default=None)
    last_used_at: Mapped[dt] = mapped_column(DateTime(timezone=True), default_factory=lambda: dt.now(UTC), init=False)


template_group_association = Table(
    "template_group_association",
    Base.metadata,
    fk_id_table_column("user_template_id", "user_templates.id"),
    fk_id_table_column("group_id", "groups.id"),
)


class NextPlan(Base, IdMixin):
    __tablename__ = "next_plans"
    __table_args__ = (
        # user_id will already have an index from the FK
        # Add if you frequently query by template
        Index("ix_next_plans_user_template_id", "user_template_id"),
    )
    user_id: Mapped[int] = fk_id_column("users.id", ondelete="CASCADE")
    user_template_id: Mapped[int | None] = fk_id_column("user_templates.id", ondelete="SET NULL")
    user: Mapped[User] = relationship(back_populates="next_plan", init=False)
    user_template: Mapped[UserTemplate | None] = relationship(back_populates="next_plans", init=False)
    data_limit: Mapped[int] = mapped_column(BigInteger, default=0)
    expire: Mapped[int | None] = mapped_column(default=None)
    add_remaining_traffic: Mapped[bool] = mapped_column(default=False, server_default="0")


class UserStatusCreate(str, Enum):
    active = "active"
    on_hold = "on_hold"


class UserTemplate(Base, IdMixin):
    __tablename__ = "user_templates"
    name: Mapped[str] = mapped_column(String(64), unique=True)
    username_prefix: Mapped[str | None] = mapped_column(String(20))
    username_suffix: Mapped[str | None] = mapped_column(String(20))
    extra_settings: Mapped[dict | None] = mapped_column(JSON(True))
    next_plans: Mapped[list[NextPlan]] = relationship(
        back_populates="user_template", cascade="all, delete-orphan", init=False
    )
    groups: Mapped[list[Group]] = relationship(secondary=template_group_association, back_populates="templates")
    data_limit: Mapped[int] = mapped_column(BigInteger, default=0)
    hwid_limit: Mapped[int | None] = mapped_column(BigInteger, default=None)
    expire_duration: Mapped[int] = mapped_column(BigInteger, default=0)  # in seconds
    on_hold_timeout: Mapped[int | None] = mapped_column(default=None)
    status: Mapped[UserStatusCreate] = mapped_column(SQLEnum(UserStatusCreate), default=UserStatusCreate.active)
    reset_usages: Mapped[bool] = mapped_column(default=False, server_default="0")
    data_limit_reset_strategy: Mapped[DataLimitResetStrategy] = mapped_column(
        SQLEnum(DataLimitResetStrategy),
        default=DataLimitResetStrategy.no_reset,
        server_default="no_reset",
    )
    is_disabled: Mapped[bool] = mapped_column(server_default="0", default=False)

    @property
    def group_ids(self):
        return [group.id for group in self.groups]


class UserUsageResetLogs(Base, IdMixin):
    __tablename__ = "user_usage_logs"
    __table_args__ = (
        # Index for user-specific queries sorted by time
        Index("ix_user_usage_logs_user_id_reset_at", "user_id", "reset_at"),
    )
    user_id: Mapped[int | None] = fk_id_column("users.id", ondelete="CASCADE", nullable=True)
    user: Mapped[User] = relationship(back_populates="usage_logs", init=False)
    used_traffic_at_reset: Mapped[int] = mapped_column(BigInteger, nullable=False)
    reset_at: Mapped[dt] = mapped_column(DateTime(timezone=True), default=lambda: dt.now(UTC), init=False)


class ProxyInbound(Base, IdMixin):
    __tablename__ = "inbounds"
    tag: Mapped[str] = mapped_column(String(256), unique=True, index=True)
    hosts: Mapped[list[ProxyHost]] = relationship(back_populates="inbound", init=False)
    groups: Mapped[list[Group]] = relationship(
        secondary=inbounds_groups_association, back_populates="inbounds", init=False
    )


@event.listens_for(ProxyInbound, "after_delete")
def delete_association_rows(mapper, connection, target):
    connection.execute(
        inbounds_groups_association.delete().where(inbounds_groups_association.c.inbound_id == target.id)
    )


class ProxyHostSecurity(str, Enum):
    inbound_default = "inbound_default"
    none = "none"
    tls = "tls"


class ProxyHostALPN(str, Enum):
    h1 = "http/1.1"
    h2 = "h2"
    h3 = "h3"


ProxyHostFingerprint = Enum(
    "ProxyHostFingerprint",
    {
        "none": "",
        "chrome": "chrome",
        "firefox": "firefox",
        "safari": "safari",
        "ios": "ios",
        "android": "android",
        "edge": "edge",
        "360": "360",
        "qq": "qq",
        "random": "random",
        "randomized": "randomized",
        "randomizednoalpn": "randomizednoalpn",
        "unsafe": "unsafe",
    },
)


class ProxyHost(Base, IdMixin):
    __tablename__ = "hosts"
    remark: Mapped[str] = mapped_column(String(256), unique=False, nullable=False)
    port: Mapped[int | None] = mapped_column(nullable=True)
    path: Mapped[str | None] = mapped_column(String(256), unique=False, nullable=True)
    priority: Mapped[int] = mapped_column(nullable=False)
    allowinsecure: Mapped[bool | None] = mapped_column(nullable=True)
    address: Mapped[set[str]] = mapped_column(StringArray(256), default_factory=set, unique=False, nullable=False)
    sni: Mapped[set[str] | None] = mapped_column(StringArray(1000), default_factory=set, unique=False, nullable=True)
    host: Mapped[set[str] | None] = mapped_column(StringArray(1000), default_factory=set, unique=False, nullable=True)
    inbound_tag: Mapped[str | None] = mapped_column(
        String(256), ForeignKey("inbounds.tag", ondelete="SET NULL", onupdate="CASCADE"), nullable=True, init=False
    )
    inbound: Mapped[ProxyInbound | None] = relationship(back_populates="hosts", init=False)
    security: Mapped[ProxyHostSecurity] = mapped_column(
        SQLEnum(ProxyHostSecurity),
        unique=False,
        default=ProxyHostSecurity.inbound_default,
    )
    alpn: Mapped[list[ProxyHostALPN] | None] = mapped_column(EnumArray(ProxyHostALPN, 14), default=list)
    fingerprint: Mapped[ProxyHostFingerprint] = mapped_column(
        SQLEnum(ProxyHostFingerprint),
        unique=False,
        default=ProxyHostSecurity.none,
        server_default=ProxyHostSecurity.none.name,
    )
    is_disabled: Mapped[bool | None] = mapped_column(default=False)
    fragment_settings: Mapped[dict[str, Any] | None] = mapped_column(JSON(none_as_null=True), default=None)
    noise_settings: Mapped[dict[str, Any] | None] = mapped_column(JSON(none_as_null=True), default=None)
    random_user_agent: Mapped[bool] = mapped_column(default=False, server_default="0")
    use_sni_as_host: Mapped[bool] = mapped_column(default=False, server_default="0")
    http_headers: Mapped[dict[str, Any] | None] = mapped_column(JSON(none_as_null=True), default=None)
    transport_settings: Mapped[dict[str, Any] | None] = mapped_column(JSON(none_as_null=True), default=None)
    mux_settings: Mapped[dict[str, Any] | None] = mapped_column(JSON(none_as_null=True), default=None)
    status: Mapped[list[UserStatus] | None] = mapped_column(EnumArray(UserStatus, 60), default=list, server_default="")
    ech: Mapped[dict[str, Any] | None] = mapped_column(JSON(none_as_null=True), default=None)
    vless_route: Mapped[str | None] = mapped_column(String(4), default=None)
    pinned_peer_cert_sha256: Mapped[str | None] = mapped_column(String(128), default=None)
    verify_peer_cert_by_name: Mapped[set[str] | None] = mapped_column(
        StringArray(1000), default_factory=set, unique=False, nullable=True
    )
    wireguard_overrides: Mapped[dict[str, Any] | None] = mapped_column(JSON(none_as_null=True), default=None)
    subscription_templates: Mapped[dict[str, Any] | None] = mapped_column(JSON(none_as_null=True), default=None)
    final_mask_settings: Mapped[dict[str, Any] | None] = mapped_column(JSON(none_as_null=True), default=None)
    cipher_suites: Mapped[str | None] = mapped_column(String(1024), default=None)


class System(Base, IdMixin):
    __tablename__ = "system"
    uplink: Mapped[int] = mapped_column(BigInteger, default=0)
    downlink: Mapped[int] = mapped_column(BigInteger, default=0)


class JWT(Base, IdMixin):
    __tablename__ = "jwt"

    secret_key: Mapped[str] = mapped_column(String(64), default=lambda: os.urandom(32).hex())


class NodeConnectionType(str, Enum):
    grpc = "grpc"
    rest = "rest"


class NodeStatus(str, Enum):
    connected = "connected"
    connecting = "connecting"
    error = "error"
    disabled = "disabled"
    limited = "limited"


class Node(Base, CreatedAtUTCMixin):
    __tablename__ = "nodes"
    name: Mapped[str] = mapped_column(CaseSensitiveString(256), unique=True)
    address: Mapped[str] = mapped_column(String(256), unique=False, nullable=False)
    port: Mapped[int] = mapped_column(unique=False, nullable=False)
    api_port: Mapped[int] = mapped_column(unique=False, nullable=False, server_default="62051")
    xray_version: Mapped[str | None] = mapped_column(String(32), nullable=True, init=False)
    message: Mapped[str | None] = mapped_column(String(1024), nullable=True, init=False)
    server_ca: Mapped[str] = mapped_column(String(2048), nullable=False)
    api_key: Mapped[str | None] = mapped_column(String(36))
    node_version: Mapped[str | None] = mapped_column(String(32), nullable=True, init=False)
    core_config_id: Mapped[int | None] = fk_id_column("core_configs.id", ondelete="SET NULL", nullable=True)
    user_usages: Mapped[list[NodeUserUsage]] = relationship(
        back_populates="node", cascade="all, delete-orphan", init=False
    )
    usages: Mapped[list[NodeUsage]] = relationship(back_populates="node", cascade="all, delete-orphan", init=False)
    usage_logs: Mapped[list[NodeUsageResetLogs]] = relationship(
        back_populates="node", cascade="all, delete-orphan", init=False
    )
    core_config: Mapped[CoreConfig | None] = relationship("CoreConfig", init=False)
    stats: Mapped[list[NodeStat]] = relationship(back_populates="node", cascade="all, delete-orphan", init=False)
    status: Mapped[NodeStatus] = mapped_column(SQLEnum(NodeStatus), default=NodeStatus.connecting)
    last_status_change: Mapped[dt | None] = mapped_column(DateTime(timezone=True), init=False)
    uplink: Mapped[int] = mapped_column(BigInteger, default=0)
    downlink: Mapped[int] = mapped_column(BigInteger, default=0)
    data_limit: Mapped[int] = mapped_column(BigInteger, default=0)
    data_limit_reset_strategy: Mapped[DataLimitResetStrategy] = mapped_column(
        SQLEnum(DataLimitResetStrategy),
        default=DataLimitResetStrategy.no_reset,
    )
    reset_time: Mapped[int] = mapped_column(default=-1, server_default=text("-1"))
    usage_coefficient: Mapped[float] = mapped_column(Float, server_default=text("1.0"), default=1)
    connection_type: Mapped[NodeConnectionType] = mapped_column(
        SQLEnum(NodeConnectionType),
        unique=False,
        default=NodeConnectionType.grpc,
        server_default=NodeConnectionType.grpc.name,
    )
    keep_alive: Mapped[int] = mapped_column(unique=False, default=0)
    default_timeout: Mapped[int] = mapped_column(default=10, server_default=text("10"))
    internal_timeout: Mapped[int] = mapped_column(default=15, server_default=text("15"))
    proxy_url: Mapped[str | None] = mapped_column(String(256), default="", unique=False, nullable=True)
    _reseted_uplink_query: Mapped[int | None] = query_expression(repr=False)
    _reseted_downlink_query: Mapped[int | None] = query_expression(repr=False)

    @hybrid_property
    def reseted_uplink(self) -> int:
        if self._reseted_uplink_query is not None:
            return int(self._reseted_uplink_query)
        return int(sum([log.uplink for log in self.usage_logs]))

    @reseted_uplink.expression
    def reseted_uplink(cls):
        return (
            select(func.sum(NodeUsageResetLogs.uplink))
            .where(NodeUsageResetLogs.node_id == cls.id)
            .label("reseted_uplink")
        )

    @hybrid_property
    def reseted_downlink(self) -> int:
        if self._reseted_downlink_query is not None:
            return int(self._reseted_downlink_query)
        return int(sum([log.downlink for log in self.usage_logs]))

    @reseted_downlink.expression
    def reseted_downlink(cls):
        return (
            select(func.sum(NodeUsageResetLogs.downlink))
            .where(NodeUsageResetLogs.node_id == cls.id)
            .label("reseted_downlink")
        )

    @property
    def lifetime_uplink(self) -> int:
        return self.reseted_uplink + self.uplink

    @property
    def lifetime_downlink(self) -> int:
        return self.reseted_downlink + self.downlink

    @property
    def lifetime_used_traffic(self) -> int:
        return self.lifetime_uplink + self.lifetime_downlink

    @hybrid_property
    def is_limited(self) -> bool:
        return self.data_limit is not None and self.data_limit > 0 and self.data_limit <= self.used_traffic

    @is_limited.expression
    def is_limited(cls):
        return and_(cls.data_limit.isnot(None), cls.data_limit > 0, cls.data_limit <= cls.used_traffic)

    @hybrid_property
    def used_traffic(self) -> int:
        return self.downlink + self.uplink

    @used_traffic.expression
    def used_traffic(cls):
        return cls.downlink + cls.uplink


class NodeUserUsage(Base, IdMixin):
    __tablename__ = "node_user_usages"
    __table_args__ = (
        UniqueConstraint("created_at", "user_id", "node_id"),
        # Indexes for common queries
        Index(
            "ix_node_user_usages_user_id_created_at", "user_id", "created_at"
        ),  # User-specific queries with time range
        Index(
            "ix_node_user_usages_node_id_created_at", "node_id", "created_at"
        ),  # Node-specific queries with time range
        Index("ix_node_user_usages_created_at", "created_at"),  # Time-based cleanup/aggregation
    )
    created_at: Mapped[dt] = mapped_column(DateTime(timezone=True), unique=False)  # 10 minute per record
    user_id: Mapped[int] = fk_id_column("users.id", ondelete="CASCADE")
    user: Mapped[User] = relationship(back_populates="node_usages", init=False)
    node_id: Mapped[int | None] = fk_id_column("nodes.id", ondelete="CASCADE")
    node: Mapped[Node] = relationship(back_populates="user_usages", init=False)
    used_traffic: Mapped[int] = mapped_column(BigInteger, default=0)


class NodeUsage(Base, IdMixin):
    __tablename__ = "node_usages"
    __table_args__ = (
        UniqueConstraint("created_at", "node_id"),
        # Index for time-based queries and cleanup
        Index("ix_node_usages_created_at", "created_at"),
        # The unique constraint already creates an index on (created_at, node_id)
    )
    created_at: Mapped[dt] = mapped_column(DateTime(timezone=True), unique=False)  # 10 minute per record
    node_id: Mapped[int | None] = fk_id_column("nodes.id", ondelete="CASCADE")
    node: Mapped[Node] = relationship(back_populates="usages", init=False)
    uplink: Mapped[int] = mapped_column(BigInteger, default=0)
    downlink: Mapped[int] = mapped_column(BigInteger, default=0)


class NodeUsageResetLogs(Base, CreatedAtUTCMixin):
    __tablename__ = "node_usage_reset_logs"
    __table_args__ = (
        # Index for node-specific queries sorted by time
        Index("ix_node_usage_reset_logs_node_id_created_at", "node_id", "created_at"),
    )
    node_id: Mapped[int] = fk_id_column("nodes.id", ondelete="CASCADE")
    node: Mapped[Node] = relationship(back_populates="usage_logs", init=False)
    uplink: Mapped[int] = mapped_column(BigInteger, nullable=False)
    downlink: Mapped[int] = mapped_column(BigInteger, nullable=False)


class NotificationReminder(Base, CreatedAtUTCMixin):
    __tablename__ = "notification_reminders"
    user_id: Mapped[int] = fk_id_column("users.id", ondelete="CASCADE")
    user: Mapped[User] = relationship(back_populates="notification_reminders", init=False)
    type: Mapped[ReminderType] = mapped_column(SQLEnum(ReminderType))
    threshold: Mapped[int | None] = mapped_column(default=None)
    expires_at: Mapped[dt | None] = mapped_column(DateTime(timezone=True), default=None)


class AdminNotificationReminder(Base, CreatedAtUTCMixin):
    __tablename__ = "admin_notification_reminders"
    __table_args__ = (
        Index("ix_admin_notification_reminders_admin_id_type", "admin_id", "type"),
        UniqueConstraint(
            "admin_id", "type", "threshold", name="uq_admin_notification_reminders_admin_id_type_threshold"
        ),
    )
    admin_id: Mapped[int] = fk_id_column("admins.id", ondelete="CASCADE")
    admin: Mapped[Admin] = relationship(back_populates="notification_reminders", init=False)
    type: Mapped[ReminderType] = mapped_column(SQLEnum(ReminderType))
    threshold: Mapped[int] = mapped_column(server_default="0", default=0)


class Group(Base, IdMixin):
    __tablename__ = "groups"
    name: Mapped[str] = mapped_column(String(64))
    users: Mapped[list[User]] = relationship(secondary=users_groups_association, back_populates="groups", init=False)
    inbounds: Mapped[list[ProxyInbound]] = relationship(secondary=inbounds_groups_association, back_populates="groups")
    templates: Mapped[list[UserTemplate]] = relationship(
        secondary=template_group_association, back_populates="groups", init=False
    )
    is_disabled: Mapped[bool] = mapped_column(server_default="0", default=False)

    @hybrid_property
    def inbound_ids(self) -> list[int]:
        return [inbound.id for inbound in self.inbounds]

    @inbound_ids.expression
    def inbound_ids(cls):
        return (
            select(func.aggregate_strings(ProxyInbound.id, ","))
            .select_from(inbounds_groups_association)
            .join(ProxyInbound, inbounds_groups_association.c.inbound_id == ProxyInbound.id)
            .where(inbounds_groups_association.c.group_id == cls.id)
            .scalar_subquery()
            .label("inbound_ids")
        )

    @hybrid_property
    def inbound_tags(self) -> list[str]:
        return [inbound.tag for inbound in self.inbounds]

    @inbound_tags.expression
    def inbound_tags(cls):
        return (
            select(func.aggregate_strings(ProxyInbound.tag, ","))
            .select_from(inbounds_groups_association)
            .join(ProxyInbound, inbounds_groups_association.c.inbound_id == ProxyInbound.id)
            .where(inbounds_groups_association.c.group_id == cls.id)
            .scalar_subquery()
            .label("inbound_tags")
        )

    @hybrid_property
    def total_users(self) -> int:
        return len(self.users)

    @total_users.expression
    def total_users(cls):
        return (
            select(func.count(users_groups_association.c.user_id))
            .where(users_groups_association.c.groups_id == cls.id)
            .scalar_subquery()
            .label("total_users")
        )


class CoreType(str, Enum):
    xray = "xray"
    wg = "wg"
    mtproto = "mtproto"
    singbox = "singbox"


class CoreConfig(Base, CreatedAtUTCMixin):
    __tablename__ = "core_configs"
    name: Mapped[str] = mapped_column(String(256))
    config: Mapped[dict[str, Any]] = mapped_column(JSON(False))
    type: Mapped[CoreType] = mapped_column(SQLEnum(CoreType), default=CoreType.xray, server_default=CoreType.xray)
    exclude_inbound_tags: Mapped[set[str] | None] = mapped_column(StringArray(2048), default_factory=set)
    fallbacks_inbound_tags: Mapped[set[str] | None] = mapped_column(StringArray(2048), default_factory=set)


class WireGuardSubnet(Base, IdMixin):
    """Allocation state of one WireGuard client subnet: a free-list plus a high-water offset.

    One row per exact client network (identical CIDRs across cores share the row). Allocating
    pops the free-list or takes next_offset; releasing pushes the offset back. Users' assigned
    IPs stay in their proxy_settings; this row only guarantees no offset is handed out twice.
    Resizing changes the network key — reconcile rebuilds the row and keeps peer IPs that still fit.
    """

    __tablename__ = "wireguard_subnets"
    network: Mapped[str] = mapped_column(String(64), unique=True)  # canonical CIDR, e.g. 10.0.0.0/24 or fd00::/64
    next_offset: Mapped[int] = mapped_column(SqliteCompatibleBigInteger, default=1)
    free_offsets: Mapped[list] = mapped_column(JSON(True), default_factory=list)


class ClientTemplate(Base, IdMixin):
    __tablename__ = "client_templates"
    __table_args__ = (
        UniqueConstraint("template_type", "name"),
        Index("ix_client_templates_template_type", "template_type"),
    )
    name: Mapped[str] = mapped_column(String(64), nullable=False)
    template_type: Mapped[str] = mapped_column(String(32), nullable=False)
    content: Mapped[str] = mapped_column(Text, nullable=False)
    is_default: Mapped[bool] = mapped_column(default=False, server_default="0")
    is_system: Mapped[bool] = mapped_column(default=False, server_default="0")


class NodeStat(Base, CreatedAtUTCMixin):
    __tablename__ = "node_stats"
    node_id: Mapped[int] = fk_id_column("nodes.id")
    node: Mapped[Node] = relationship(back_populates="stats", init=False)
    mem_total: Mapped[int] = mapped_column(BigInteger, unique=False, nullable=False)
    mem_used: Mapped[int] = mapped_column(BigInteger, unique=False, nullable=False)
    cpu_cores: Mapped[int] = mapped_column(unique=False, nullable=False)
    cpu_usage: Mapped[float] = mapped_column(unique=False, nullable=False)
    incoming_bandwidth_speed: Mapped[int] = mapped_column(BigInteger, unique=False, nullable=False)
    outgoing_bandwidth_speed: Mapped[int] = mapped_column(BigInteger, unique=False, nullable=False)


class Settings(Base, IdMixin):
    __tablename__ = "settings"
    telegram: Mapped[dict] = mapped_column(JSON())
    webhook: Mapped[dict] = mapped_column(JSON())
    notification_settings: Mapped[dict] = mapped_column(JSON())
    notification_enable: Mapped[dict] = mapped_column(JSON())
    subscription: Mapped[dict] = mapped_column(JSON())
    hwid: Mapped[dict] = mapped_column(JSON())
    general: Mapped[dict] = mapped_column(JSON())


class AdminRole(Base, CreatedAtUTCMixin):
    __tablename__ = "admin_roles"
    name: Mapped[str] = mapped_column(String(64), unique=True)
    is_owner: Mapped[bool] = mapped_column(default=False, server_default="0")
    permissions: Mapped[dict] = mapped_column(PostgresJSONB, default_factory=dict)
    limits: Mapped[dict] = mapped_column(PostgresJSONB, default_factory=dict)
    features: Mapped[dict] = mapped_column(PostgresJSONB, default_factory=dict)
    access: Mapped[dict] = mapped_column(PostgresJSONB, default_factory=dict)
    hwid: Mapped[dict] = mapped_column(PostgresJSONB, default_factory=dict)
    disabled_when_limited: Mapped[bool] = mapped_column(default=False, server_default="0")
    disconnect_users_when_limited: Mapped[bool] = mapped_column(default=True, server_default="1")
    disconnect_users_when_disabled: Mapped[bool] = mapped_column(default=True, server_default="1")
    admins: Mapped[list[Admin]] = relationship(back_populates="role", init=False, viewonly=True, lazy="noload")

    @hybrid_property
    def is_builtin(self) -> bool:
        """True for the 3 default roles (owner, administrator, operator) that cannot be deleted."""
        return self.id <= 3

    @is_builtin.expression
    def is_builtin(cls):
        return cls.id <= 3


class APIKeyStatus(str, Enum):
    active = "active"
    disabled = "disabled"


class APIKey(Base, CreatedAtUTCMixin):
    __tablename__ = "api_keys"
    __table_args__ = (
        UniqueConstraint("key_hash"),
        UniqueConstraint("admin_id", "name"),
        Index("ix_api_keys_admin_id", "admin_id"),
        Index("ix_api_keys_created_at", "created_at"),
        Index("ix_api_keys_expire_date", "expire_date"),
    )

    admin_id: Mapped[int] = fk_id_column("admins.id", ondelete="CASCADE")
    admin: Mapped[Admin] = relationship(back_populates="api_keys", init=False)
    name: Mapped[str] = mapped_column(String(128), nullable=False)
    key_hash: Mapped[str] = mapped_column(String(128), nullable=False)
    api_key_trimmed: Mapped[str] = mapped_column(String(16))
    permissions: Mapped[dict] = mapped_column(PostgresJSONB, default_factory=dict)
    inherit_permissions: Mapped[bool] = mapped_column(default=True, server_default="1")
    note: Mapped[str | None] = mapped_column(String(512), default=None)
    expire_date: Mapped[dt | None] = mapped_column(DateTime(timezone=True), default=None)
    revoked_at: Mapped[dt | None] = mapped_column(DateTime(timezone=True), default=None)
    status: Mapped[APIKeyStatus] = mapped_column(
        SQLEnum(APIKeyStatus, name="apikeystatus", create_constraint=True),
        default=APIKeyStatus.active,
        server_default="active",
    )

    @hybrid_property
    def is_expired(self) -> bool:
        """True when expire_date is set and is in the past."""
        if self.expire_date is None:
            return False
        expire_at = self.expire_date if self.expire_date.tzinfo else self.expire_date.replace(tzinfo=UTC)
        return expire_at <= dt.now(UTC)

    @is_expired.expression
    def is_expired(cls):
        return and_(cls.expire_date.isnot(None), cls.expire_date <= func.current_timestamp())

    @property
    def is_usable(self) -> bool:
        """False if the key is disabled, its admin is missing/disabled, or it has expired."""
        if self.status == APIKeyStatus.disabled:
            return False
        if self.admin is None or self.admin.status == AdminStatus.disabled:
            return False
        return not self.is_expired


class TempKey(Base):
    __tablename__ = "temp_keys"

    key: Mapped[str] = mapped_column(String(36), primary_key=True, init=True)
    action: Mapped[str] = mapped_column(String(32))
    expires_at: Mapped[dt] = mapped_column(DateTime(timezone=True))
    used_at: Mapped[dt | None] = mapped_column(DateTime(timezone=True), default=None)
    used_by_ip: Mapped[str | None] = mapped_column(String(45), default=None)
