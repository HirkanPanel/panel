from collections.abc import AsyncIterator, Sequence
from contextlib import asynccontextmanager
from copy import deepcopy
from datetime import UTC, datetime, timedelta
from typing import Literal

from sqlalchemy import and_, bindparam, case, delete, desc, func, literal, not_, or_, select, update
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import joinedload, selectinload, with_expression
from sqlalchemy.sql import Select
from sqlalchemy.sql.functions import coalesce

from app.db.compiles_types import DateDiff
from app.db.models import (
    Admin,
    DataLimitResetStrategy,
    Group,
    NextPlan,
    NodeUserUsage,
    NotificationReminder,
    ReminderType,
    User,
    UserStatus,
    UserSubscriptionUpdate,
    UserUsageResetLogs,
    users_groups_association,
)
from app.models.proxy import ProxyTable
from app.models.stats import (
    Period,
    UserCountMetric,
    UserCountMetricStat,
    UserCountMetricStatsList,
    UserUsageStat,
    UserUsageStatsList,
    validate_user_count_metric_scope,
)
from app.models.user import (
    ExpiredUsersQuery,
    UserCreate,
    UserListQuery,
    UserModify,
    UserNotificationResponse,
    UserSimpleListQuery,
    UserSimpleSortField,
    UserSimpleSortOption,
    UserSortField,
    UserSortOption,
)
from app.models.validators import MAX_ON_HOLD_EXPIRE_DURATION_SECONDS
from app.subscription.sub_update_buffer import flush_user_sub_updates, queue_user_sub_update
from config import user_cleanup_settings

from .general import (
    _build_trunc_expression,
    attach_timezone_to_period_start,
    build_json_proxy_settings_search_condition,
    get_complete_period_start_for_filter,
    to_utc_for_filter,
)
from .group import get_groups_by_ids
from .wireguard import (
    release_allocations_by_user_ids,
    release_users_allocations,
    sync_user_allocations,
    sync_users_allocations,
    tags_from_groups,
)

_ONLINE_USERS_WINDOW = timedelta(minutes=2)


def _review_user_select_stmt(*, load_groups: bool = True) -> Select:
    """Load relations needed for status review jobs without materializing usage logs."""
    return _build_user_select_stmt(
        load_admin=True,
        load_admin_role=True,
        load_next_plan=True,
        load_usage_logs=False,
        load_groups=load_groups,
        load_lifetime_used_traffic=True,
    )


def _user_reset_traffic_subquery():
    return (
        select(func.coalesce(func.sum(UserUsageResetLogs.used_traffic_at_reset), 0))
        .where(UserUsageResetLogs.user_id == User.id)
        .correlate(User)
        .scalar_subquery()
    )


def _snapshot_reseted_usage(users: list[User]) -> dict[int, int]:
    """Keep the already-loaded lifetime aggregate across bulk UPDATEs."""
    return {user.id: int(user.reseted_usage) for user in users}


def _restore_reseted_usage(users: list[User], reseted_usage: dict[int, int]) -> None:
    for user in users:
        if user.id in reseted_usage:
            user.__dict__["_reseted_usage_query"] = reseted_usage[user.id]


def _safe_on_hold_expire_duration(duration: int | None) -> int | None:
    if duration is None or duration <= 0:
        return None
    return min(duration, MAX_ON_HOLD_EXPIRE_DURATION_SECONDS)


def _resolve_enabled_user_status(user: User) -> UserStatus:
    now = datetime.now(UTC)
    if user.expire is not None and user.expire.replace(tzinfo=UTC) <= now:
        return UserStatus.expired
    if user.data_limit is not None and user.data_limit > 0 and user.used_traffic >= user.data_limit:
        return UserStatus.limited
    if user.on_hold_expire_duration is not None:
        return UserStatus.on_hold
    return UserStatus.active


def _build_user_select_stmt(
    *,
    load_admin: bool = True,
    load_admin_role: bool = False,
    load_next_plan: bool = True,
    load_usage_logs: bool = True,
    load_groups: bool = True,
    join_groups: bool = False,
    load_lifetime_used_traffic: bool = False,
) -> Select:
    """Build a user select statement with eager-load options."""
    stmt = select(User)
    options = []
    if load_admin:
        admin_loader = joinedload(User.admin)
        if load_admin_role:
            admin_loader = admin_loader.selectinload(Admin.role)
        options.append(admin_loader)
    if load_next_plan:
        options.append(joinedload(User.next_plan))
    if load_usage_logs:
        options.append(selectinload(User.usage_logs))
    if load_groups:
        options.append(joinedload(User.groups) if join_groups else selectinload(User.groups))
    if options:
        stmt = stmt.options(*options)
    if load_lifetime_used_traffic:
        stmt = stmt.options(with_expression(User._reseted_usage_query, _user_reset_traffic_subquery()))
    return stmt


async def load_user_attrs(
    user: User,
    *,
    load_admin: bool = True,
    load_admin_role: bool = False,
    load_next_plan: bool = True,
    load_usage_logs: bool = True,
    load_groups: bool = True,
):
    if load_admin:
        await user.awaitable_attrs.admin
        if load_admin_role and user.admin is not None:
            await user.admin.awaitable_attrs.role
    if load_next_plan:
        await user.awaitable_attrs.next_plan
    if load_usage_logs:
        await user.awaitable_attrs.usage_logs
    if load_groups:
        await user.awaitable_attrs.groups


async def refresh_and_load_user(
    db: AsyncSession,
    user: User,
    *,
    load_admin: bool = True,
    load_admin_role: bool = False,
    load_next_plan: bool = True,
    load_usage_logs: bool = True,
    load_groups: bool = True,
):
    await db.refresh(user)
    await load_user_attrs(
        user,
        load_admin=load_admin,
        load_admin_role=load_admin_role,
        load_next_plan=load_next_plan,
        load_usage_logs=load_usage_logs,
        load_groups=load_groups,
    )


async def get_user(
    db: AsyncSession,
    username: str,
    *,
    load_admin: bool = True,
    load_admin_role: bool = False,
    load_next_plan: bool = True,
    load_usage_logs: bool = True,
    load_groups: bool = True,
    join_groups: bool = False,
    load_lifetime_used_traffic: bool = False,
    admin_id: int | None = None,
) -> User | None:
    """
    Retrieves a user by username.

    Args:
        db (AsyncSession): Database session.
        username (str): The username of the user.
        admin_id: If provided, only return the user if they belong to this admin.

    Returns:
        Optional[User]: The user object if found, else None.
    """
    stmt = _build_user_select_stmt(
        load_admin=load_admin,
        load_admin_role=load_admin_role,
        load_next_plan=load_next_plan,
        load_usage_logs=load_usage_logs,
        load_groups=load_groups,
        join_groups=join_groups,
        load_lifetime_used_traffic=load_lifetime_used_traffic,
    ).where(User.username == username)

    if admin_id is not None:
        stmt = stmt.where(User.admin_id == admin_id)

    return (await db.execute(stmt)).unique().scalar_one_or_none()


async def get_user_by_id(
    db: AsyncSession,
    user_id: int,
    *,
    load_admin: bool = True,
    load_admin_role: bool = False,
    load_next_plan: bool = True,
    load_usage_logs: bool = True,
    load_groups: bool = True,
    join_groups: bool = False,
    load_lifetime_used_traffic: bool = False,
    admin_id: int | None = None,
) -> User | None:
    """
    Retrieves a user by user ID.

    Args:
        db (AsyncSession): Database session.
        user_id (int): The ID of the user.
        admin_id: If provided, only return the user if they belong to this admin.

    Returns:
        Optional[User]: The user object if found, else None.
    """
    stmt = _build_user_select_stmt(
        load_admin=load_admin,
        load_admin_role=load_admin_role,
        load_next_plan=load_next_plan,
        load_usage_logs=load_usage_logs,
        load_groups=load_groups,
        join_groups=join_groups,
        load_lifetime_used_traffic=load_lifetime_used_traffic,
    ).where(User.id == user_id)

    if admin_id is not None:
        stmt = stmt.where(User.admin_id == admin_id)

    return (await db.execute(stmt)).unique().scalar_one_or_none()


async def get_user_lifetime_used_traffic(db: AsyncSession, user_id: int) -> int:
    stmt = (
        select(
            func.coalesce(func.sum(UserUsageResetLogs.used_traffic_at_reset), 0) + func.coalesce(User.used_traffic, 0)
        )
        .select_from(User)
        .outerjoin(UserUsageResetLogs, UserUsageResetLogs.user_id == User.id)
        .where(User.id == user_id)
        .group_by(User.id)
    )
    result = await db.execute(stmt)
    value = result.scalar_one_or_none()
    return int(value or 0)


async def get_existing_usernames(db: AsyncSession, usernames: Sequence[str]) -> set[str]:
    """
    Returns the set of usernames that already exist in the database.
    """
    if not usernames:
        return set()

    stmt = select(User.username).where(User.username.in_(usernames))
    result = await db.execute(stmt)
    return set(result.scalars().all())


async def get_users_with_proxy_settings(
    db: AsyncSession,
    *,
    exclude_user_id: int | None = None,
) -> list[User]:
    """
    Retrieve users for proxy-settings related operations without eager-loading relations.
    """
    stmt = select(User)
    if exclude_user_id is not None:
        stmt = stmt.where(User.id != exclude_user_id)

    result = await db.execute(stmt)
    return list(result.scalars().all())


def _build_user_sort_clause(sort_option: UserSortOption):
    field_map = {
        UserSortField.username: User.username,
        UserSortField.used_traffic: User.used_traffic,
        UserSortField.data_limit: User.data_limit,
        UserSortField.expire: User.expire,
        UserSortField.created_at: User.created_at,
    }
    nullable_field_map = {
        UserSortField.edit_at: User.edit_at,
        UserSortField.online_at: User.online_at,
    }

    if sort_option.field in field_map:
        column = field_map[sort_option.field]
        return column.desc() if sort_option.value.startswith("-") else column.asc()

    column = nullable_field_map[sort_option.field]
    return (
        case((column.is_(None), 1), else_=0).asc(),
        column.desc() if sort_option.value.startswith("-") else column.asc(),
    )


def _build_user_simple_sort_clause(sort_option: UserSimpleSortOption):
    field_map = {
        UserSimpleSortField.id: User.id,
        UserSimpleSortField.username: User.username,
    }
    column = field_map[sort_option.field]
    return column.desc() if sort_option.value.startswith("-") else column.asc()


async def get_users(
    db: AsyncSession,
    query: UserListQuery,
    admin: Admin | None = None,
    return_with_count: bool = False,
    load_admin_role: bool = False,
    load_usage_logs: bool = True,
    load_lifetime_used_traffic: bool = False,
) -> list[User] | tuple[list[User], int]:
    """
    Retrieves users based on various filters.

    Args:
        db: Database session.
        query: Structured user list query filters.
        admin: Admin filter.
        return_with_count: Whether to return total count.
        load_usage_logs: Whether to materialize reset-history rows.
        load_lifetime_used_traffic: Whether to calculate lifetime usage with an aggregate.

    Returns:
        List of users or tuple with (users, count) if return_with_count is True.
    """
    admin_loader = selectinload(User.admin)
    if load_admin_role:
        admin_loader = admin_loader.selectinload(Admin.role)

    options = [
        admin_loader,
        selectinload(User.next_plan),
        selectinload(User.groups),
    ]
    if load_usage_logs:
        options.append(selectinload(User.usage_logs))
    if load_lifetime_used_traffic:
        options.append(with_expression(User._reseted_usage_query, _user_reset_traffic_subquery()))
    stmt = select(User).options(*options)

    filters = []
    if query.ids:
        filters.append(User.id.in_(query.ids))
    if query.username:
        filters.append(User.username.in_(query.username))
    if query.usernames:
        filters.append(User.username.in_(query.usernames))
    if query.search:
        filters.append(or_(User.username.ilike(f"%{query.search}%"), User.note.ilike(f"%{query.search}%")))

    if query.status:
        if isinstance(query.status, list):
            filters.append(User.status.in_(query.status))
        else:
            filters.append(User.status == query.status)
    if admin:
        filters.append(User.admin_id == admin.id)
    if query.owner or query.admin_ids:
        stmt = stmt.join(User.admin)
        if query.owner:
            filters.append(Admin.username.in_(query.owner))
        if query.admin_ids:
            filters.append(Admin.id.in_(query.admin_ids))
    if query.data_limit_reset_strategy:
        if isinstance(query.data_limit_reset_strategy, list):
            filters.append(User.data_limit_reset_strategy.in_(query.data_limit_reset_strategy))
        else:
            filters.append(User.data_limit_reset_strategy == query.data_limit_reset_strategy)
    if query.no_data_limit:
        filters.append(or_(User.data_limit.is_(None), User.data_limit == 0))
    else:
        if query.data_limit_min is not None:
            filters.append(
                and_(User.data_limit.is_not(None), User.data_limit > 0, User.data_limit >= query.data_limit_min)
            )
        if query.data_limit_max is not None:
            filters.append(
                and_(User.data_limit.is_not(None), User.data_limit > 0, User.data_limit <= query.data_limit_max)
            )
    if query.no_expire:
        filters.append(and_(User.expire.is_(None), User.status != UserStatus.on_hold))
    else:
        if query.expire_after is not None:
            filters.append(and_(User.expire.is_not(None), User.expire >= query.expire_after))
        if query.expire_before is not None:
            filters.append(and_(User.expire.is_not(None), User.expire <= query.expire_before))
    if query.online_after is not None:
        filters.append(and_(User.online_at.is_not(None), User.online_at >= query.online_after))
    if query.online_before is not None:
        filters.append(and_(User.online_at.is_not(None), User.online_at <= query.online_before))
    if query.online:
        filters.append(and_(User.online_at.is_not(None), User.online_at >= datetime.now(UTC) - _ONLINE_USERS_WINDOW))

    if query.group_ids:
        filters.append(User.groups.any(Group.id.in_(query.group_ids)))
    if query.no_group:
        filters.append(~User.groups.any())
    if query.proxy_id:
        filters.append(build_json_proxy_settings_search_condition(db, User.proxy_settings, query.proxy_id))

    if filters:
        stmt = stmt.where(and_(*filters))

    if query.sort:
        sort_clauses = []
        for sort_option in query.sort:
            clause = _build_user_sort_clause(sort_option)
            if isinstance(clause, tuple):
                sort_clauses.extend(clause)
            else:
                sort_clauses.append(clause)
        stmt = stmt.order_by(*sort_clauses)

    total = None
    if return_with_count:
        count_stmt = select(func.count()).select_from(stmt.subquery())
        result = await db.execute(count_stmt)
        total = result.scalar()

    if query.offset:
        stmt = stmt.offset(query.offset)
    if query.limit:
        stmt = stmt.limit(query.limit)

    result = await db.execute(stmt)
    users = list(result.unique().scalars().all())

    if return_with_count:
        return users, total
    return users


async def get_users_simple(
    db: AsyncSession,
    query: UserSimpleListQuery,
    admin: Admin | None = None,
) -> tuple[list[tuple[int, str]], int]:
    """
    Retrieves lightweight user data with only id and username.

    Args:
        db: Database session.
        query: Structured lightweight user list filters.
        admin: Admin filter (for scope-based authorization).

    Returns:
        Tuple of (list of (id, username) tuples, total_count).
    """
    stmt = select(User.id, User.username)

    filters = []
    if query.ids:
        filters.append(User.id.in_(query.ids))
    if query.usernames:
        filters.append(User.username.in_(query.usernames))
    if query.search:
        filters.append(User.username.ilike(f"%{query.search}%"))
    if admin:
        filters.append(User.admin_id == admin.id)

    if filters:
        stmt = stmt.where(and_(*filters))

    if query.sort:
        sort_list = []
        for sort_option in query.sort:
            clause = _build_user_simple_sort_clause(sort_option)
            if isinstance(clause, tuple):
                sort_list.extend(clause)
            else:
                sort_list.append(clause)
        stmt = stmt.order_by(*sort_list)

    # Get count BEFORE pagination (always)
    count_stmt = select(func.count()).select_from(stmt.subquery())
    total = (await db.execute(count_stmt)).scalar()

    # Apply pagination or safety limit
    if not query.all:
        if query.offset:
            stmt = stmt.offset(query.offset)
        if query.limit:
            stmt = stmt.limit(query.limit)
    else:
        stmt = stmt.limit(10000)  # Safety limit when all=true

    # Execute and return
    result = await db.execute(stmt)
    rows = result.all()

    return rows, total


async def get_expired_users(
    db: AsyncSession,
    query: ExpiredUsersQuery,
    admin_id: int | None = None,
):
    conditions = _cleanup_target_user_conditions(query.expired_after, query.expired_before, admin_id, query.target)
    stmt = select(User).where(*conditions)

    return (await db.execute(stmt)).unique().scalars().all()


def _cleanup_target_user_conditions(
    expired_after: datetime | None = None,
    expired_before: datetime | None = None,
    admin_id: int | None = None,
    target: Literal["expired", "limited", "on_hold", "disabled"] = "expired",
):
    if target == "expired":
        # Time-expired users: date range filters on the expiration date.
        conditions = [User.is_expired]
        if expired_after:
            conditions.append(User.expire >= expired_after)
        if expired_before:
            conditions.append(User.expire <= expired_before)
    else:
        # For limited / on_hold / disabled: date range filters apply to
        # last_status_change (i.e. when the user entered that status).
        status_map = {
            "limited": UserStatus.limited,
            "on_hold": UserStatus.on_hold,
            "disabled": UserStatus.disabled,
        }
        conditions = [User.status == status_map[target]]
        if expired_after:
            conditions.append(User.last_status_change >= expired_after.replace(tzinfo=None))
        if expired_before:
            conditions.append(User.last_status_change <= expired_before.replace(tzinfo=None))

    if admin_id is not None:
        conditions.append(User.admin_id == admin_id)

    return conditions


async def remove_expired_users(
    db: AsyncSession,
    expired_after: datetime | None = None,
    expired_before: datetime | None = None,
    admin_id: int | None = None,
    target: Literal["expired", "limited", "on_hold", "disabled"] = "expired",
    dry_run: bool = False,
) -> list[str]:
    conditions = _cleanup_target_user_conditions(expired_after, expired_before, admin_id, target)

    rows = (await db.execute(select(User.id, User.username).where(*conditions))).all()
    if not rows:
        return []

    usernames = [username for _, username in rows]

    if dry_run:
        return usernames

    user_ids = [user_id for user_id, _ in rows]

    for start in range(0, len(user_ids), 1000):
        chunk = user_ids[start : start + 1000]
        await release_allocations_by_user_ids(db, chunk)
        await _delete_user_dependencies(db, chunk)
        await db.execute(delete(User).where(User.id.in_(chunk)))
    await db.commit()

    return usernames


async def get_active_to_expire_users(db: AsyncSession) -> list[User]:
    stmt = _review_user_select_stmt().where(User.status == UserStatus.active).where(User.is_expired)

    return list((await db.execute(stmt)).unique().scalars().all())


async def get_active_to_limited_users(db: AsyncSession) -> list[User]:
    stmt = _review_user_select_stmt().where(User.status == UserStatus.active).where(User.is_limited)

    return list((await db.execute(stmt)).unique().scalars().all())


async def get_on_hold_to_active_users(db: AsyncSession) -> list[User]:
    stmt = _review_user_select_stmt().where(User.status == UserStatus.on_hold).where(User.become_online)

    return list((await db.execute(stmt)).unique().scalars().all())


async def get_users_to_reset_data_usage(db: AsyncSession) -> list[User]:
    """
    Retrieves users whose data usage needs to be reset based on their reset strategy.
    """
    last_reset_subq = (
        select(
            UserUsageResetLogs.user_id,
            func.max(UserUsageResetLogs.reset_at).label("last_reset_at"),
        )
        .group_by(UserUsageResetLogs.user_id)
        .subquery()
    )

    last_reset_time = coalesce(last_reset_subq.c.last_reset_at, User.created_at)

    reset_strategy_to_days = {
        DataLimitResetStrategy.day: 1,
        DataLimitResetStrategy.week: 7,
        DataLimitResetStrategy.month: 30,
        DataLimitResetStrategy.year: 365,
    }

    num_days_to_reset_case = case(
        *((User.data_limit_reset_strategy == strategy, days) for strategy, days in reset_strategy_to_days.items()),
        else_=None,
    )

    stmt = (
        _review_user_select_stmt()
        .outerjoin(last_reset_subq, User.id == last_reset_subq.c.user_id)
        .where(
            User.status.in_([UserStatus.active, UserStatus.limited]),
            User.data_limit_reset_strategy != DataLimitResetStrategy.no_reset,
            DateDiff(func.now(), last_reset_time) >= num_days_to_reset_case,
        )
    )

    return list((await db.execute(stmt)).unique().scalars().all())


async def get_usage_percentage_reached_users(db: AsyncSession, percentage: int) -> list[User]:
    """
    Get active users who have reached or exceeded the specified usage percentage threshold
    and don't have an existing notification reminder for this threshold.
    """
    # Subquery to check for existing notification reminders
    existing_reminder_subq = (
        select(NotificationReminder.user_id)
        .where(
            NotificationReminder.user_id == User.id,
            NotificationReminder.type == ReminderType.data_usage,
            NotificationReminder.threshold == percentage,
        )
        .exists()
    )

    stmt = (
        _review_user_select_stmt()
        .options(joinedload(User.notification_reminders))
        .where(User.status == UserStatus.active)
        .where(User.usage_percentage >= percentage)
        .where(not_(existing_reminder_subq))  # Only users without existing reminders
    )

    return list((await db.execute(stmt)).unique().scalars().all())


async def get_days_left_reached_users(db: AsyncSession, days: int) -> list[User]:
    """
    Get active users who have reached or exceeded the specified days left threshold
    and don't have an existing notification reminder for this threshold.
    """
    # Subquery to check for existing notification reminders
    existing_reminder_subq = (
        select(NotificationReminder.user_id)
        .where(
            NotificationReminder.user_id == User.id,
            NotificationReminder.type == ReminderType.expiration_date,
            NotificationReminder.threshold == days,
        )
        .exists()
    )

    stmt = (
        _review_user_select_stmt()
        .options(joinedload(User.notification_reminders))
        .where(User.status == UserStatus.active)
        .where(User.expire.isnot(None))
        .where(User.days_left == days)
        .where(not_(existing_reminder_subq))  # Only users without existing reminders
    )

    return list((await db.execute(stmt)).unique().scalars().all())


async def get_user_usages(
    db: AsyncSession,
    user_id: int,
    start: datetime,
    end: datetime,
    period: Period,
    node_id: int | None = None,
    group_by_node: bool = False,
) -> UserUsageStatsList:
    """
    Retrieves user usages within a specified date range.
    Groups data by periods in the timezone of the start/end parameters.
    """
    # Build the appropriate truncation expression
    trunc_expr = _build_trunc_expression(db, period, NodeUserUsage.created_at, start)

    # Filter using UTC timestamps (DB stores naive UTC) from first complete bucket
    start_utc = get_complete_period_start_for_filter(start, period)
    end_utc = to_utc_for_filter(end)
    conditions = [
        NodeUserUsage.created_at >= start_utc,
        NodeUserUsage.created_at < end_utc,
        NodeUserUsage.user_id == user_id,
    ]

    if node_id is not None:
        conditions.append(NodeUserUsage.node_id == node_id)
    else:
        node_id = -1

    dialect = db.bind.dialect.name
    if group_by_node:
        stmt = (
            select(
                trunc_expr.label("period_start"),
                func.coalesce(NodeUserUsage.node_id, 0).label("node_id"),
                func.sum(NodeUserUsage.used_traffic).label("total_traffic"),
            )
            .where(and_(*conditions))
            .group_by(trunc_expr, NodeUserUsage.node_id)
            .order_by(trunc_expr)
        )

    else:
        stmt = (
            select(trunc_expr.label("period_start"), func.sum(NodeUserUsage.used_traffic).label("total_traffic"))
            .where(and_(*conditions))
            .group_by(trunc_expr)
            .order_by(trunc_expr)
        )

    result = await db.execute(stmt)

    stats = {}
    for row in result.mappings():
        row_dict = dict(row)
        node_id_val = row_dict.pop("node_id", node_id)

        # Attach timezone info to period_start
        attach_timezone_to_period_start(row_dict, start.tzinfo, dialect)

        if node_id_val not in stats:
            stats[node_id_val] = []
        stats[node_id_val].append(UserUsageStat(**row_dict))

    return UserUsageStatsList(period=period, start=start, end=end, stats=stats)


async def get_users_count_by_admin(db: AsyncSession, admin_id: int | None) -> int:
    """
    Gets the total count of users belonging to a specific admin.

    Args:
        db (AsyncSession): Database session.
        admin_id (int | None): Admin ID to filter by. If None, counts all users.

    Returns:
        int: Total count of users for the given admin.
    """
    stmt = select(func.count(User.id))
    if admin_id is not None:
        stmt = stmt.where(User.admin_id == admin_id)
    return (await db.execute(stmt)).scalar_one() or 0


async def lock_admin_quota_row(db: AsyncSession, admin_id: int) -> None:
    """Lock an admin row before quota-sensitive user creation."""
    if db.bind.dialect.name == "sqlite":
        await db.execute(update(Admin).where(Admin.id == admin_id).values(id=Admin.id))
        return

    await db.execute(select(Admin.id).where(Admin.id == admin_id).with_for_update())


async def get_users_by_usernames(
    db: AsyncSession,
    usernames: Sequence[str],
    *,
    load_admin_role: bool = False,
) -> list[User]:
    if not usernames:
        return []

    result = await db.execute(
        _build_user_select_stmt(load_admin_role=load_admin_role).where(User.username.in_(usernames))
    )
    users_by_username = {user.username: user for user in result.unique().scalars().all()}
    return [users_by_username[username] for username in usernames if username in users_by_username]


async def get_users_by_ids(
    db: AsyncSession,
    user_ids: Sequence[int],
    *,
    load_admin_role: bool = False,
) -> list[User]:
    if not user_ids:
        return []

    result = await db.execute(_build_user_select_stmt(load_admin_role=load_admin_role).where(User.id.in_(user_ids)))
    users_by_id = {user.id: user for user in result.unique().scalars().all()}
    return [users_by_id[user_id] for user_id in user_ids if user_id in users_by_id]


async def get_users_count(db: AsyncSession, status: UserStatus = None, admin_id: int | None = None) -> int:
    """
    Gets the total count of users with optional filters.

    Args:
        db (AsyncSession): Database session.
        status (UserStatus, optional): Filter by user status.
        admin_id (int, optional): Filter by admin.
    Returns:
        int: Total count of users.
    """
    stmt = select(func.count(User.id))

    filters = []
    if status:
        filters.append(User.status == status)
    if admin_id:
        filters.append(User.admin_id == admin_id)

    if filters:
        stmt = stmt.where(and_(*filters))

    result = await db.execute(stmt)
    return result.scalar()


def _build_user_count_metrics_query(
    statuses: list[UserStatus], online_since: datetime, admin_id: int | None = None
) -> Select:
    """Build one index-aware query for dashboard user counts."""
    if admin_id is not None:
        status_columns = [
            select(func.count(User.id))
            .where(User.admin_id == admin_id, User.status == status)
            .scalar_subquery()
            .label(status.value)
            for status in statuses
        ]
        online_column = (
            select(func.count(User.id))
            .where(
                User.admin_id == admin_id,
                User.online_at.isnot(None),
                User.online_at >= online_since,
            )
            .scalar_subquery()
            .label("online")
        )
        return select(*status_columns, online_column)

    status_columns = [func.count(case((User.status == status, User.id))).label(status.value) for status in statuses]
    online_column = func.count(case((and_(User.online_at.isnot(None), User.online_at >= online_since), User.id))).label(
        "online"
    )
    return select(*status_columns, online_column)


async def get_users_count_metrics(
    db: AsyncSession,
    statuses: list[UserStatus],
    online_window: timedelta,
    admin_id: int | None = None,
) -> tuple[dict[str, int], int]:
    """Return per-status, total, and recent-online user counts in one SELECT.

    The ``total`` value includes only the requested statuses. Pass every
    ``UserStatus`` value when a complete user count is required.
    """
    stmt = _build_user_count_metrics_query(statuses, datetime.now(UTC) - online_window, admin_id)
    row = (await db.execute(stmt)).one()

    status_counts = {status.value: int(getattr(row, status.value) or 0) for status in statuses}
    status_counts["total"] = sum(status_counts.values())
    return status_counts, int(row.online or 0)


async def create_user(
    db: AsyncSession, new_user: UserCreate, groups: list[Group], admin: Admin, *, commit: bool = True
) -> User:
    """
    Creates a new user.

    Args:
        db (AsyncSession): Database session.
        new_user (UserCreate): User creation data.
        groups (list[Group]): Groups to assign to user.
        admin (Admin): Admin creating the user.

    Returns:
        User: Created user object.
    """
    db_user = User(
        **new_user.model_dump(exclude={"group_ids", "expire", "proxy_settings", "next_plan", "on_hold_timeout"})
    )
    db_user.admin = admin
    db_user.groups = groups
    db_user.expire = new_user.expire or None
    db_user.on_hold_timeout = new_user.on_hold_timeout or None

    if new_user.hwid_limit is not None:
        db_user.hwid_limit = new_user.hwid_limit

    db_user.proxy_settings = new_user.proxy_settings.dict()

    db.add(db_user)
    await db.flush()
    await sync_user_allocations(db, db_user, accessible_tags=await tags_from_groups(groups))

    if new_user.next_plan:
        db_user.next_plan = NextPlan(user_id=db_user.id, **new_user.next_plan.model_dump())
        db.add(db_user.next_plan)
    if commit:
        await db.commit()
        await refresh_and_load_user(db, db_user)
    return db_user


async def create_users_bulk(
    db: AsyncSession, new_users: list[UserCreate], groups: list[Group], admin: Admin, *, commit: bool = True
) -> list[User]:
    """
    Creates multiple users in a single commit for better performance.
    """
    if not new_users:
        return []

    db_users: list[User] = []
    for new_user in new_users:
        db_user = User(
            **new_user.model_dump(exclude={"group_ids", "expire", "proxy_settings", "next_plan", "on_hold_timeout"})
        )
        db_user.admin = admin
        db_user.groups = list(groups)
        db_user.expire = new_user.expire or None
        db_user.on_hold_timeout = new_user.on_hold_timeout or None
        db_user.hwid_limit = new_user.hwid_limit if new_user.hwid_limit is not None else None
        db_user.proxy_settings = new_user.proxy_settings.dict()
        db_users.append(db_user)

    db.add_all(db_users)
    await db.flush()
    group_tags = await tags_from_groups(groups)
    await sync_users_allocations(db, db_users, tags_by_user={user.id: group_tags for user in db_users})

    next_plans: list[NextPlan] = []
    for db_user, new_user in zip(db_users, new_users):
        if new_user.next_plan:
            next_plans.append(NextPlan(user_id=db_user.id, **new_user.next_plan.model_dump()))

    if next_plans:
        db.add_all(next_plans)
        await db.flush()

    if commit:
        await db.commit()
        for user in db_users:
            await refresh_and_load_user(db, user)

    return db_users


async def _delete_user_dependencies(db: AsyncSession, user_ids: list[int]):
    """Remove all rows that reference the given user IDs."""
    if not user_ids:
        return

    await db.execute(users_groups_association.delete().where(users_groups_association.c.user_id.in_(user_ids)))


async def remove_user(db: AsyncSession, db_user: User) -> User:
    """
    Removes a user from the database.

    Args:
        db (AsyncSession): Database session.
        db_user (User): User to remove.

    Returns:
        User: Removed user object.
    """
    await release_users_allocations(db, [db_user])
    await _delete_user_dependencies(db, [db_user.id])
    await db.execute(delete(User).where(User.id == db_user.id))
    await db.commit()
    return db_user


async def remove_users(db: AsyncSession, db_users: list[User]):
    """
    Removes multiple users from the database.

    Args:
        db (AsyncSession): Database session.
        db_users (list[User]): List of user objects to be removed.
    """
    if not db_users:
        return

    user_ids = list({user.id for user in db_users})

    await release_users_allocations(db, db_users)
    await _delete_user_dependencies(db, user_ids)
    await db.execute(delete(User).where(User.id.in_(user_ids)))
    await db.commit()


async def modify_user(
    db: AsyncSession,
    db_user: User,
    modify: UserModify,
    *,
    groups: list[Group] | None = None,
    commit: bool = True,
) -> User:
    """
    Modify a user's information.

    Args:
        db (AsyncSession): Database session.
        dbuser (User): User to update.
        modify (UserModify): Modified user data.

    Returns:
        User: Updated user object.
    """
    remove_usage_reminder = False
    remove_expiration_reminder = False

    if modify.proxy_settings is not None:
        db_user.proxy_settings = modify.proxy_settings.dict()
    if modify.group_ids is not None:
        db_user.groups = groups or await get_groups_by_ids(db, modify.group_ids, load_users=False, load_inbounds=True)
        await sync_user_allocations(db, db_user, accessible_tags=await tags_from_groups(db_user.groups))

    if modify.status is not None:
        if modify.status == UserStatus.active and db_user.status == UserStatus.disabled:
            db_user.status = _resolve_enabled_user_status(db_user)
        else:
            db_user.status = modify.status

    if modify.status is UserStatus.on_hold:
        db_user.expire = None
        remove_expiration_reminder = True

    elif modify.expire == 0:
        db_user.expire = None
        remove_expiration_reminder = True
        if db_user.status is UserStatus.expired:
            db_user.status = UserStatus.active

    elif modify.expire is not None:
        db_user.expire = modify.expire
        if db_user.status in [UserStatus.active, UserStatus.expired]:
            if not db_user.expire or db_user.expire.replace(tzinfo=UTC) > datetime.now(UTC):
                db_user.status = UserStatus.active

                remove_expiration_reminder = True
            else:
                db_user.status = UserStatus.expired

    if modify.data_limit is not None:
        db_user.data_limit = modify.data_limit or None
        if db_user.status not in [UserStatus.expired, UserStatus.disabled]:
            if not db_user.data_limit or db_user.used_traffic < db_user.data_limit:
                if db_user.status != UserStatus.on_hold:
                    db_user.status = UserStatus.active

                remove_usage_reminder = True
            else:
                db_user.status = UserStatus.limited

    if modify.note is not None:
        db_user.note = modify.note or None

    if modify.data_limit_reset_strategy is not None:
        db_user.data_limit_reset_strategy = modify.data_limit_reset_strategy

    if modify.on_hold_timeout == 0:
        db_user.on_hold_timeout = None
    elif modify.on_hold_timeout is not None:
        db_user.on_hold_timeout = modify.on_hold_timeout

    if modify.on_hold_expire_duration is not None:
        db_user.on_hold_expire_duration = modify.on_hold_expire_duration

    if modify.hwid_limit is not None:
        db_user.hwid_limit = modify.hwid_limit

    if modify.next_plan is not None:
        db_user.next_plan = NextPlan(
            user_id=db_user.id,
            user_template_id=modify.next_plan.user_template_id,
            data_limit=modify.next_plan.data_limit,
            expire=modify.next_plan.expire,
            add_remaining_traffic=modify.next_plan.add_remaining_traffic,
        )
    elif db_user.next_plan is not None:
        await db.delete(db_user.next_plan)

    db_user.edit_at = datetime.now(UTC)

    if remove_usage_reminder or remove_expiration_reminder:
        id = db_user.id
        usage_percentage = db_user.usage_percentage
        days_left = db_user.days_left

    if remove_usage_reminder:
        await delete_user_passed_notification_reminders(db, id, ReminderType.data_usage, usage_percentage)
    if remove_expiration_reminder:
        await delete_user_passed_notification_reminders(db, id, ReminderType.expiration_date, days_left)

    if commit:
        await db.commit()
        await refresh_and_load_user(db, db_user)
    return db_user


async def _reset_user_traffic_and_log(db: AsyncSession, db_user: User):
    """Helper to reset user traffic and log the action."""
    await db_user.awaitable_attrs.next_plan
    usage_log = UserUsageResetLogs(
        user_id=db_user.id,
        used_traffic_at_reset=db_user.used_traffic,
    )
    db.add(usage_log)

    if db_user.next_plan:
        await db.delete(db_user.next_plan)
        db_user.next_plan = None

    db_user.used_traffic = 0


async def clear_user_node_usages(db: AsyncSession, user_id: int, *, before: datetime | None = None) -> None:
    stmt = delete(NodeUserUsage).where(NodeUserUsage.user_id == user_id)
    if before is not None:
        stmt = stmt.where(NodeUserUsage.created_at <= before)
    await db.execute(stmt)


async def reset_user_data_usage(
    db: AsyncSession, db_user: User, *, clean_chart_data: bool = False, commit: bool = True
) -> User:
    """
    Resets the data usage of a user and logs the reset.

    Args:
        db (AsyncSession): Database session.
        dbuser (User): The user object whose data usage is to be reset.

    Returns:
        User: The updated user object.
    """
    await _reset_user_traffic_and_log(db, db_user)
    await delete_user_passed_notification_reminders(db, db_user.id, ReminderType.data_usage, 0)
    if clean_chart_data:
        await clear_user_node_usages(db, db_user.id)

    if db_user.status == UserStatus.limited:
        db_user.status = UserStatus.active

    if commit:
        await db.commit()
        await refresh_and_load_user(db, db_user)
    return db_user


async def bulk_reset_user_data_usage(
    db: AsyncSession, users: list[User], *, clean_chart_data: bool = False, commit: bool = True
) -> list[User]:
    """
    Resets the data usage for a list of users and logs the reset.

    Args:
        db (AsyncSession): Database session.
        users (list[User]): The list of user objects whose data usage is to be reset.

    Returns:
        list[User]: The updated list of user objects.
    """
    for db_user in users:
        await _reset_user_traffic_and_log(db, db_user)
        await delete_user_passed_notification_reminders(db, db_user.id, ReminderType.data_usage, 0)
        if clean_chart_data:
            await clear_user_node_usages(db, db_user.id)
        if db_user.status == UserStatus.limited:
            db_user.status = UserStatus.active
    if commit:
        await db.commit()
        for user in users:
            await refresh_and_load_user(db, user, load_admin_role=True)
    return users


def build_revoked_proxy_settings(db_user: User) -> dict:
    proxy_settings = ProxyTable()
    proxy_settings.shadowsocks.method = db_user.proxy_settings.get("shadowsocks", {}).get(
        "method", "chacha20-ietf-poly1305"
    )
    proxy_settings.wireguard.peer_ips = db_user.proxy_settings.get("wireguard", {}).get("peer_ips", []) or []
    return proxy_settings.dict()


async def reset_user_by_next(db: AsyncSession, db_user: User, *, clean_chart_data: bool = False) -> User:
    """
    Resets the data usage of a user based on next user.

    Args:
        db (AsyncSession): Database session.
        dbuser (User): The user object whose data usage is to be reset.

    Returns:
        User: The updated user object.
    """
    remaining_traffic = (db_user.data_limit or 0) - db_user.used_traffic
    if db_user.next_plan.user_template_id is None:
        db_user.data_limit = db_user.next_plan.data_limit + (
            0 if not db_user.next_plan.add_remaining_traffic else remaining_traffic
        )
        db_user.expire = (
            timedelta(seconds=db_user.next_plan.expire) + datetime.now(UTC) if db_user.next_plan.expire else None
        )
    else:
        await db_user.next_plan.awaitable_attrs.user_template
        await db_user.next_plan.user_template.awaitable_attrs.groups
        db_user.groups = db_user.next_plan.user_template.groups
        await sync_user_allocations(db, db_user, accessible_tags=await tags_from_groups(db_user.groups))
        db_user.data_limit = db_user.next_plan.user_template.data_limit + (
            0 if not db_user.next_plan.add_remaining_traffic else remaining_traffic
        )
        if db_user.next_plan.user_template.status is UserStatus.on_hold:
            db_user.status = UserStatus.on_hold
            db_user.on_hold_expire_duration = db_user.next_plan.user_template.expire_duration
            db_user.on_hold_timeout = db_user.next_plan.user_template.on_hold_timeout
            db_user.expire = None
        else:
            db_user.expire = (
                timedelta(seconds=db_user.next_plan.user_template.expire_duration) + datetime.now(UTC)
                if db_user.next_plan.user_template.expire_duration
                else None
            )

        if db_user.next_plan.user_template.extra_settings:
            proxy_settings = deepcopy(db_user.proxy_settings)
            proxy_settings["shadowsocks"]["method"] = (
                db_user.next_plan.user_template.extra_settings["method"]
                if db_user.next_plan.user_template.extra_settings["method"]
                else "chacha20-ietf-poly1305"
            )
            db_user.proxy_settings = proxy_settings
        db_user.data_limit_reset_strategy = db_user.next_plan.user_template.data_limit_reset_strategy

    await _reset_user_traffic_and_log(db, db_user)
    await delete_user_passed_notification_reminders(db, db_user.id, ReminderType.data_usage, 0)
    if clean_chart_data:
        await clear_user_node_usages(db, db_user.id)
    db_user.status = UserStatus.active

    await db.commit()
    await refresh_and_load_user(db, db_user)
    return db_user


async def revoke_user_sub(db: AsyncSession, db_user: User, *, proxy_settings: dict | None = None) -> User:
    """
    Revokes the subscription of a user and updates proxies settings.

    Args:
        db (AsyncSession): Database session.
        db_user (User): The user object whose subscription is to be revoked.

    Returns:
        User: The updated user object.
    """
    db_user.sub_revoked_at = datetime.now(UTC)
    db_user.proxy_settings = proxy_settings if proxy_settings is not None else build_revoked_proxy_settings(db_user)
    await db.commit()
    await refresh_and_load_user(db, db_user)
    return db_user


async def bulk_revoke_user_sub(
    db: AsyncSession, users: list[User], *, proxy_settings_by_user_id: dict[int, dict] | None = None
) -> list[User]:
    """
    Revoke subscriptions for multiple users in a single transaction.

    Args:
        db (AsyncSession): Database session.
        users (list[User]): Users whose subscriptions should be revoked.

    Returns:
        list[User]: The refreshed users.
    """
    revoked_at = datetime.now(UTC)
    for user in users:
        user.sub_revoked_at = revoked_at
        user.proxy_settings = (
            proxy_settings_by_user_id.get(user.id)
            if proxy_settings_by_user_id is not None and user.id in proxy_settings_by_user_id
            else build_revoked_proxy_settings(user)
        )

    await db.commit()
    for user in users:
        await refresh_and_load_user(db, user, load_admin_role=True)
    return users


@asynccontextmanager
async def _subscription_update_read_session(db: AsyncSession) -> AsyncIterator[AsyncSession]:
    """Read committed updates without reusing the caller's pre-flush snapshot."""
    await flush_user_sub_updates()
    # MySQL/MariaDB REPEATABLE READ may already have a snapshot from the
    # authorization/user lookup. A separate session sees the flushed rows
    # without committing or rolling back any work owned by the caller.
    async with AsyncSession(bind=db.bind, expire_on_commit=False) as read_db:
        yield read_db


async def user_sub_update(
    db: AsyncSession, user_id: int, user_agent: str, ip: str | None = None, hwid: str | None = None
) -> None:
    """
    Queue a subscription-update row. The request session is unused; writes are
    flushed in the background so the public /sub path stays read-mostly.

    Args:
        db (AsyncSession): Database session (unused; kept for call-site compatibility).
        user_id (int): The user id whose subscription is to be updated.
        user_agent (str): The user agent string.
        ip (str | None): The client IP address.
        hwid (str | None): The hardware ID of the client.
    """
    _ = db
    await queue_user_sub_update(user_id, user_agent, ip=ip, hwid=hwid)


async def get_users_sub_update_list(
    db: AsyncSession, user_id: int, offset: int = 0, limit: int = 10
) -> tuple[Sequence[UserSubscriptionUpdate], int]:
    stmt = (
        select(UserSubscriptionUpdate)
        .where(UserSubscriptionUpdate.user_id == user_id)
        .order_by(desc(UserSubscriptionUpdate.created_at))
    )

    async with _subscription_update_read_session(db) as read_db:
        result = await read_db.execute(select(func.count()).select_from(stmt.subquery()))
        count = result.scalar() or 0

        if offset:
            stmt = stmt.offset(offset)
        if limit:
            stmt = stmt.limit(limit)

        result = (await read_db.execute(stmt)).unique().scalars().all()

    return result, count


def _subscription_update_from_clause(
    user_id: int | None = None,
    admin_id: int | None = None,
):
    conditions = []
    if user_id is not None:
        conditions.append(UserSubscriptionUpdate.user_id == user_id)
        from_clause = UserSubscriptionUpdate.__table__
    else:
        from_clause = UserSubscriptionUpdate.__table__.join(User, UserSubscriptionUpdate.user_id == User.id)
        if admin_id:
            conditions.append(User.admin_id == admin_id)
    return from_clause, conditions


async def get_users_subscription_agent_counts(
    db: AsyncSession,
    user_id: int | None = None,
    admin_id: int | None = None,
    start: datetime | None = None,
    end: datetime | None = None,
    period: Period | None = None,
) -> list[tuple[str, int]]:
    stmt = select(UserSubscriptionUpdate.user_agent, func.count().label("count"))
    from_clause, conditions = _subscription_update_from_clause(user_id=user_id, admin_id=admin_id)

    if start is not None:
        start_utc = (
            get_complete_period_start_for_filter(start, period) if period is not None else to_utc_for_filter(start)
        )
        conditions.append(UserSubscriptionUpdate.created_at >= start_utc)
    if end is not None:
        conditions.append(UserSubscriptionUpdate.created_at < to_utc_for_filter(end))

    stmt = stmt.select_from(from_clause)
    if conditions:
        stmt = stmt.where(and_(*conditions))
    stmt = stmt.group_by(UserSubscriptionUpdate.user_agent)

    async with _subscription_update_read_session(db) as read_db:
        result = await read_db.execute(stmt)
    return [(agent, count) for agent, count in result.all()]


async def get_users_subscription_agent_stats(
    db: AsyncSession,
    start: datetime,
    end: datetime,
    period: Period = Period.hour,
    user_id: int | None = None,
    admin_id: int | None = None,
) -> list[dict]:
    """Retrieve subscription update counts grouped by agent and period."""
    trunc_expr = _build_trunc_expression(db, period, UserSubscriptionUpdate.created_at, start)
    start_utc = get_complete_period_start_for_filter(start, period)
    end_utc = to_utc_for_filter(end)
    from_clause, conditions = _subscription_update_from_clause(user_id=user_id, admin_id=admin_id)
    conditions.extend(
        [
            UserSubscriptionUpdate.created_at >= start_utc,
            UserSubscriptionUpdate.created_at < end_utc,
        ]
    )

    stmt = (
        select(
            trunc_expr.label("period_start"),
            UserSubscriptionUpdate.user_agent.label("agent"),
            func.count().label("count"),
        )
        .select_from(from_clause)
        .where(and_(*conditions))
        .group_by(trunc_expr, UserSubscriptionUpdate.user_agent)
        .order_by(trunc_expr)
    )

    async with _subscription_update_read_session(db) as read_db:
        result = await read_db.execute(stmt)
    dialect = db.bind.dialect.name
    rows = []
    for row in result.mappings():
        row_dict = dict(row)
        attach_timezone_to_period_start(row_dict, start.tzinfo, dialect)
        rows.append(row_dict)
    return rows


async def autodelete_expired_users(
    db: AsyncSession, include_limited_users: bool = False
) -> list[UserNotificationResponse]:
    """
    Deletes expired (optionally also limited) users whose auto-delete time has passed.

    Args:
        db (AsyncSession): Database session
        include_limited_users (bool, optional): Whether to delete limited users as well.
            Defaults to False.

    Returns:
        list[UserNotificationResponse]: List of deleted users.
    """
    target_status = [UserStatus.expired] if not include_limited_users else [UserStatus.expired, UserStatus.limited]

    auto_delete = func.coalesce(User.auto_delete_in_days, literal(user_cleanup_settings.autodelete_days))

    query = (
        select(
            User,
            auto_delete,  # Use global auto-delete days as fallback
        )
        .where(
            auto_delete >= 0,  # Negative values prevent auto-deletion
            User.status.in_(target_status),
        )
        .options(joinedload(User.admin))
    )

    expired_users = [
        user
        for (user, auto_delete) in (await db.execute(query)).unique()
        if user.last_status_change.replace(tzinfo=UTC) + timedelta(days=auto_delete) <= datetime.now(UTC)
    ]

    result: list[UserNotificationResponse] = []
    if expired_users:
        for user in expired_users:
            await load_user_attrs(user)
            result.append(UserNotificationResponse.model_validate(user))

        await remove_users(db, expired_users)

    return result


async def get_all_users_usages(
    db: AsyncSession,
    admins: Sequence[str] | None,
    start: datetime,
    end: datetime,
    period: Period = Period.hour,
    node_id: int | None = None,
    group_by_node: bool = False,
) -> UserUsageStatsList:
    """
    Retrieves aggregated usage data for all users of an admin within a specified time range,
    grouped by the specified time period.
    Groups data by periods in the timezone of the start/end parameters.

    Args:
        db (AsyncSession): Database session for querying.
        admins (Sequence[str] | None): Admin usernames to filter users by. If None/empty, include all admins.
        start (datetime): Start of the period (with timezone).
        end (datetime): End of the period (with timezone).
        period (Period): Time period to group by ('minute', 'hour', 'day', 'month').
        node_id (Optional[int]): Filter results by specific node ID if provided

    Returns:
        UserUsageStatsList: Aggregated usage data for each period.
    """
    admins_filter = admins or None

    # Build the appropriate truncation expression
    trunc_expr = _build_trunc_expression(db, period, NodeUserUsage.created_at, start)

    # Filter using UTC timestamps (DB stores naive UTC) from first complete bucket
    start_utc = get_complete_period_start_for_filter(start, period)
    end_utc = to_utc_for_filter(end)
    conditions = [
        NodeUserUsage.created_at >= start_utc,
        NodeUserUsage.created_at < end_utc,
    ]
    if admins_filter:
        conditions.append(Admin.username.in_(admins_filter))

    if node_id is not None:
        conditions.append(NodeUserUsage.node_id == node_id)
    else:
        node_id = -1

    dialect = db.bind.dialect.name
    from_clause = NodeUserUsage.__table__.join(User, User.id == NodeUserUsage.user_id)
    if admins_filter:
        from_clause = from_clause.join(Admin, Admin.id == User.admin_id)

    if group_by_node:
        stmt = (
            select(
                trunc_expr.label("period_start"),
                func.coalesce(NodeUserUsage.node_id, 0).label("node_id"),
                func.sum(NodeUserUsage.used_traffic).label("total_traffic"),
            )
            .select_from(from_clause)
            .where(and_(*conditions))
            .group_by(trunc_expr, NodeUserUsage.node_id)
            .order_by(trunc_expr)
        )
    else:
        stmt = (
            select(trunc_expr.label("period_start"), func.sum(NodeUserUsage.used_traffic).label("total_traffic"))
            .select_from(from_clause)
            .where(and_(*conditions))
            .group_by(trunc_expr)
            .order_by(trunc_expr)
        )

    result = await db.execute(stmt)

    stats = {}
    for row in result.mappings():
        row_dict = dict(row)
        node_id_val = row_dict.pop("node_id", node_id)

        # Attach timezone info to period_start
        attach_timezone_to_period_start(row_dict, start.tzinfo, dialect)

        if node_id_val not in stats:
            stats[node_id_val] = []
        stats[node_id_val].append(UserUsageStat(**row_dict))

    return UserUsageStatsList(period=period, start=start, end=end, stats=stats)


async def get_user_count_metric_stats(
    db: AsyncSession,
    admins: Sequence[str] | None,
    start: datetime,
    end: datetime,
    period: Period = Period.hour,
    metric: UserCountMetric = UserCountMetric.online,
    node_id: int | None = None,
    group_by_node: bool = False,
) -> UserCountMetricStatsList:
    """Retrieves one distinct user count metric from node_user_usages."""
    validate_user_count_metric_scope(metric, node_id=node_id, group_by_node=group_by_node)

    query_parts = _build_user_count_query_parts(db, admins, start, end, period, node_id)
    count_expr = _build_user_count_metric_expression(metric).label("count")
    total_stmt = select(count_expr).select_from(query_parts["from_clause"]).where(and_(*query_parts["conditions"]))

    if group_by_node:
        stmt = (
            select(
                query_parts["trunc_expr"].label("period_start"),
                func.coalesce(NodeUserUsage.node_id, 0).label("node_id"),
                count_expr,
            )
            .select_from(query_parts["from_clause"])
            .where(and_(*query_parts["conditions"]))
            .group_by(query_parts["trunc_expr"], NodeUserUsage.node_id)
            .order_by(query_parts["trunc_expr"], NodeUserUsage.node_id)
        )
    else:
        stmt = (
            select(query_parts["trunc_expr"].label("period_start"), count_expr)
            .select_from(query_parts["from_clause"])
            .where(and_(*query_parts["conditions"]))
            .group_by(query_parts["trunc_expr"])
            .order_by(query_parts["trunc_expr"])
        )

    total_result = await db.execute(total_stmt)
    result = await db.execute(stmt)
    count_during_period = total_result.scalar_one() or 0

    stats = {}
    for row in result.mappings():
        row_dict = dict(row)
        node_id_val = row_dict.pop("node_id", query_parts["stats_key"])

        attach_timezone_to_period_start(row_dict, start.tzinfo, query_parts["dialect"])

        if node_id_val not in stats:
            stats[node_id_val] = []
        stats[node_id_val].append(UserCountMetricStat(**row_dict))

    return UserCountMetricStatsList(
        metric=metric,
        period=period,
        start=start,
        end=end,
        count_during_period=count_during_period,
        stats=stats,
    )


def _build_user_count_query_parts(
    db: AsyncSession,
    admins: Sequence[str] | None,
    start: datetime,
    end: datetime,
    period: Period,
    node_id: int | None,
) -> dict:
    admins_filter = admins or None
    trunc_expr = _build_trunc_expression(db, period, NodeUserUsage.created_at, start)
    start_utc = get_complete_period_start_for_filter(start, period)
    end_utc = to_utc_for_filter(end)
    conditions = [
        NodeUserUsage.created_at >= start_utc,
        NodeUserUsage.created_at < end_utc,
    ]

    if admins_filter:
        conditions.append(Admin.username.in_(admins_filter))

    stats_key = node_id
    if node_id is not None:
        conditions.append(NodeUserUsage.node_id == node_id)
    else:
        stats_key = -1

    from_clause = NodeUserUsage.__table__.join(User, User.id == NodeUserUsage.user_id)
    if admins_filter:
        from_clause = from_clause.join(Admin, Admin.id == User.admin_id)

    return {
        "conditions": conditions,
        "dialect": db.bind.dialect.name,
        "from_clause": from_clause,
        "stats_key": stats_key,
        "trunc_expr": trunc_expr,
    }


def _build_user_count_metric_expression(metric: UserCountMetric):
    if metric == UserCountMetric.online:
        return func.count(func.distinct(NodeUserUsage.user_id))
    if metric == UserCountMetric.expired:
        return func.count(func.distinct(case((User.status == UserStatus.expired, NodeUserUsage.user_id), else_=None)))
    if metric == UserCountMetric.limited:
        return func.count(func.distinct(case((User.status == UserStatus.limited, NodeUserUsage.user_id), else_=None)))
    raise ValueError(f"Unsupported user count metric: {metric}")


async def update_users_status(db: AsyncSession, users: list[User], status: UserStatus) -> list[User]:
    """
    Updates a users status and records the time of change.

    Args:
        db (AsyncSession): Database session.
        users list[User]: The users list to update.
        status (UserStatus): The new status.

    Returns:
        list[User]: The updated user objects.
    """
    if not users:
        return []

    user_ids = [user.id for user in users]
    changed_at = datetime.now(UTC)
    reseted_usage = _snapshot_reseted_usage(users)
    stmt = (
        update(User)
        .where(User.id.in_(user_ids))
        .values(status=status, last_status_change=changed_at)
        .execution_options(synchronize_session=False)
    )
    await db.execute(stmt)
    await db.commit()

    # These users were eager-loaded by the scheduled status queries. Keep their
    # relationships intact instead of refreshing every user after the bulk update.
    for user in users:
        user.status = status
        user.last_status_change = changed_at
    _restore_reseted_usage(users, reseted_usage)
    return users


async def set_owner(db: AsyncSession, db_user: User, admin: Admin) -> User:
    """
    Sets the owner (admin) of a user.

    Args:
        db (AsyncSession): Database session.
        db_user (User): The user object whose owner is to be set.
        admin (Admin): The admin to set as owner.

    Returns:
        User: The updated user object.
    """
    old_admin = db_user.admin
    db_user.admin = admin

    # Update admin traffic counters
    if old_admin and old_admin.id != admin.id:
        old_admin.used_traffic -= db_user.used_traffic
        admin.used_traffic += db_user.used_traffic

    await db.commit()
    await refresh_and_load_user(db, db_user)
    return db_user


async def bulk_set_owner(db: AsyncSession, users: list[User], admin: Admin) -> list[User]:
    """
    Set the same owner for multiple users in a single transaction.

    Args:
        db (AsyncSession): Database session.
        users (list[User]): Users to update.
        admin (Admin): Admin that should become the owner.

    Returns:
        list[User]: The refreshed users.
    """
    # Group users by old admin to update traffic counters
    admin_traffic_changes = {}
    total_traffic_to_add = 0

    for user in users:
        old_admin = user.admin
        if old_admin and old_admin.id != admin.id:
            if old_admin.id not in admin_traffic_changes:
                admin_traffic_changes[old_admin.id] = 0
            admin_traffic_changes[old_admin.id] -= user.used_traffic
        total_traffic_to_add += user.used_traffic
        user.admin = admin

    # Update old admins' traffic
    for admin_id, traffic_change in admin_traffic_changes.items():
        await db.execute(
            update(Admin).where(Admin.id == admin_id).values(used_traffic=Admin.used_traffic + traffic_change)
        )

    # Update new admin's traffic
    if total_traffic_to_add > 0:
        await db.execute(
            update(Admin).where(Admin.id == admin.id).values(used_traffic=Admin.used_traffic + total_traffic_to_add)
        )

    await db.commit()
    for user in users:
        await refresh_and_load_user(db, user)
    return users


async def start_users_expire(db: AsyncSession, users: list[User]) -> list[User]:
    """
    Starts the expiration timer for a user.

    Args:
        db (AsyncSession): Database session.
        users list[User]: The users list whose expiration timer is to be started.

    Returns:
        list[User]: The updated users list.
    """
    if not users:
        return []

    now = datetime.now(UTC)
    params = []
    # Core UPDATE expires mapped state, including query_expression. Keep the
    # already-loaded lifetime aggregate so later pydantic validation stays async-safe.
    reseted_usage = _snapshot_reseted_usage(users)
    for user in users:
        duration = _safe_on_hold_expire_duration(user.on_hold_expire_duration)
        expire_time = now + timedelta(seconds=duration) if duration is not None else None
        user.expire = expire_time
        user.on_hold_expire_duration = None
        user.on_hold_timeout = None
        user.status = UserStatus.active
        params.append({"u_id": user.id, "u_expire": expire_time})

    await db.execute(
        update(User.__table__)
        .where(User.__table__.c.id == bindparam("u_id"))
        .values(
            expire=bindparam("u_expire"),
            on_hold_expire_duration=None,
            on_hold_timeout=None,
            status=UserStatus.active,
        )
        .execution_options(synchronize_session=False),
        params,
    )
    await db.commit()
    _restore_reseted_usage(users, reseted_usage)
    return users


async def create_notification_reminder(
    db: AsyncSession, reminder_type: ReminderType, expires_at: datetime, user_id: int, threshold: int | None = None
) -> NotificationReminder:
    """
    Creates a new notification reminder.

    Args:
        db (AsyncSession): The database session.
        reminder_type (ReminderType): The type of reminder.
        expires_at (datetime): The expiration time of the reminder.
        user_id (int): The ID of the user associated with the reminder.
        threshold (Optional[int]): The threshold value to check for (e.g., days left or usage percent).

    Returns:
        NotificationReminder: The newly created NotificationReminder object.
    """
    reminder = NotificationReminder(type=reminder_type, expires_at=expires_at, user_id=user_id)
    if threshold is not None:
        reminder.threshold = threshold
    db.add(reminder)
    await db.commit()
    return reminder


async def bulk_create_notification_reminders(db: AsyncSession, reminder_data: list[dict]) -> None:
    """
    Bulk creates notification reminders.

    Args:
        db (AsyncSession): The database session.
        reminder_data (List[dict]): List of reminder data dicts with keys: user_id, type, threshold, expires_at
    """
    if not reminder_data:
        return

    reminders = []
    for data in reminder_data:
        reminder = NotificationReminder(
            type=data["type"], expires_at=data["expires_at"], user_id=data["user_id"], threshold=data.get("threshold")
        )
        reminders.append(reminder)

    db.add_all(reminders)
    await db.commit()


async def delete_user_passed_notification_reminders(
    db: AsyncSession, user_id: int, type: ReminderType, threshold: int
) -> None:
    """
    Deletes user reminders passed.

    Args:
        db (AsyncSession): The database session.
        user_id (int): The ID of the user.
        reminder_type (ReminderType): The type of reminder to delete.
        threshold (int): The threshold to delete (e.g., days left or usage percent).
    """
    conditions = [NotificationReminder.user_id == user_id, NotificationReminder.type == type]

    if type == ReminderType.data_usage:
        conditions.append(NotificationReminder.threshold > threshold)
    if type == ReminderType.expiration_date:
        conditions.append(NotificationReminder.threshold < threshold)

    stmt = delete(NotificationReminder).where(and_(*conditions))
    await db.execute(stmt)
