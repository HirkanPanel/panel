import react from '@vitejs/plugin-react'
import tailwindcss from '@tailwindcss/vite'
import { defineConfig } from 'vite'
import svgr from 'vite-plugin-svgr'
import path from 'path'
import { VitePWA } from 'vite-plugin-pwa'

export default defineConfig({
  base: process.env.BASE_URL,
  clearScreen: false,
  server: {
    host: true,
    watch: {
      ignored: ['**/build/**'],
    },
  },
  build: {
    outDir: 'build',
    assetsDir: 'statics',
    emptyOutDir: false,
    rollupOptions: {
      output: {
        manualChunks(id) {
          const normalizedId = id.replace(/\\/g, '/')

          if (
            normalizedId.includes('/node_modules/react/') ||
            normalizedId.includes('/node_modules/react-dom/') ||
            normalizedId.includes('/node_modules/scheduler/') ||
            normalizedId.includes('react-dom/index.js?commonjs-es-import')
          ) {
            return 'react'
          }

          if (normalizedId.includes('/node_modules/react-router/') || normalizedId.includes('/node_modules/react-router-dom/')) {
            return 'react-router'
          }

          if (normalizedId.includes('/node_modules/@tanstack/react-query/') || normalizedId.includes('/node_modules/@tanstack/query-core/')) {
            return 'react-query'
          }

          if (normalizedId.includes('/node_modules/recharts/')) {
            return 'recharts'
          }

          if (normalizedId.includes('/node_modules/@radix-ui/react-slot/')) {
            return 'radix-slot'
          }

          if (
            normalizedId.includes('/node_modules/@radix-ui/react-dialog/') ||
            normalizedId.includes('/node_modules/@radix-ui/react-alert-dialog/') ||
            normalizedId.includes('/node_modules/@radix-ui/react-toast/')
          ) {
            return 'radix-dialog'
          }

          if (
            normalizedId.includes('/node_modules/@radix-ui/react-popover/') ||
            normalizedId.includes('/node_modules/@radix-ui/react-dropdown-menu/') ||
            normalizedId.includes('/node_modules/@radix-ui/react-hover-card/') ||
            normalizedId.includes('/node_modules/@radix-ui/react-tooltip/') ||
            normalizedId.includes('/node_modules/@radix-ui/react-select/')
          ) {
            return 'radix-popover'
          }

          if (
            normalizedId.includes('/node_modules/@radix-ui/react-tabs/') ||
            normalizedId.includes('/node_modules/@radix-ui/react-accordion/') ||
            normalizedId.includes('/node_modules/@radix-ui/react-collapsible/')
          ) {
            return 'radix-navigation'
          }

          if (
            normalizedId.includes('/node_modules/@radix-ui/react-checkbox/') ||
            normalizedId.includes('/node_modules/@radix-ui/react-radio-group/') ||
            normalizedId.includes('/node_modules/@radix-ui/react-switch/') ||
            normalizedId.includes('/node_modules/@radix-ui/react-label/')
          ) {
            return 'radix-forms'
          }

          if (
            normalizedId.includes('/node_modules/@radix-ui/react-scroll-area/') ||
            normalizedId.includes('/node_modules/@radix-ui/react-separator/') ||
            normalizedId.includes('/node_modules/@radix-ui/react-progress/') ||
            normalizedId.includes('/node_modules/@radix-ui/react-avatar/')
          ) {
            return 'radix-layout'
          }

          if (normalizedId.includes('/node_modules/@radix-ui/react-toggle/') || normalizedId.includes('/node_modules/@radix-ui/react-toggle-group/')) {
            return 'radix-toggle'
          }

          if (
            normalizedId.includes('/node_modules/i18next/') ||
            normalizedId.includes('/node_modules/react-i18next/') ||
            normalizedId.includes('/node_modules/i18next-browser-languagedetector/') ||
            normalizedId.includes('/node_modules/i18next-http-backend/')
          ) {
            return 'i18n'
          }

          if (normalizedId.includes('/node_modules/lodash.debounce/')) {
            return 'lodash'
          }

          if (normalizedId.includes('/node_modules/dayjs/')) {
            return 'dayjs'
          }

          if (
            normalizedId.includes('/node_modules/clsx/') ||
            normalizedId.includes('/node_modules/uuid/') ||
            normalizedId.includes('/node_modules/date-fns/') ||
            normalizedId.includes('/node_modules/date-fns-jalali/')
          ) {
            return 'utils'
          }
        },
      },
    },
  },
  resolve: {
    dedupe: ['react', 'react-dom'],
    tsconfigPaths: true,
    alias: [
      {
        find: '@',
        replacement: path.resolve(import.meta.dirname, 'src'),
      },
    ],
  },
  optimizeDeps: {
    holdUntilCrawlEnd: false,
    entries: ['index.html'],
    include: [
      'react',
      'react-dom',
      'react/jsx-runtime',
      'react/jsx-dev-runtime',
      '@tanstack/react-query',
      'dayjs',
      'lodash.debounce',
      'react-use-websocket',
    ],
    exclude: ['monaco-editor', '@monaco-editor/react', 'ace-builds', 'react-ace', 'lucide-react'],
  },
  plugins: [
    tailwindcss(),
    react(),
    svgr(),
    VitePWA({
      manifest: { name: 'Hirkan', short_name: 'Hirkan', start_url: '/dashboard/', scope: '/dashboard/', icons: [{ src: '/statics/favicon/logo-pwa.png', sizes: '512x512', type: 'image/png' }] },
      registerType: 'prompt',
      injectRegister: false,
      workbox: {
        navigateFallback: '/index.html',
        globPatterns: ['**/*.{js,css,html,ico,png,svg,woff2}'],
        // Monaco is loaded lazily in editor dialogs, so its largest chunks
        // should stay network-fetched instead of bloating the app shell precache.
        globIgnores: ['statics/editor.api*.js', 'statics/ts.worker*.js'],
        cleanupOutdatedCaches: false,
        skipWaiting: false,
        clientsClaim: false,
      },
    }),
  ],
})
