import asyncio
import signal

from config import runtime_settings
from role import Role

runtime_settings.role = Role.SCHEDULER

from app import create_app
from app.lifecycle import lifespan
from app.nats import is_nats_enabled
from app.utils.logger import get_logger

logger = get_logger("scheduler-worker")
app = create_app()


async def main():
    if not is_nats_enabled():
        logger.warning(
            "NATS is disabled; notification dispatching will only work when the scheduler shares a process with the API."
        )

    stop_event = asyncio.Event()

    def handle_signal():
        stop_event.set()

    loop = asyncio.get_running_loop()
    loop.add_signal_handler(signal.SIGINT, handle_signal)
    loop.add_signal_handler(signal.SIGTERM, handle_signal)

    async with lifespan(app):
        try:
            logger.info("Scheduler worker started...")
            await stop_event.wait()
        except asyncio.CancelledError:
            pass
        finally:
            logger.info("Scheduler worker shutting down...")


if __name__ == "__main__":
    try:
        if hasattr(asyncio, "run"):
            asyncio.run(main())
        else:
            loop = asyncio.get_event_loop()
            loop.run_until_complete(main())
    except KeyboardInterrupt:
        pass
